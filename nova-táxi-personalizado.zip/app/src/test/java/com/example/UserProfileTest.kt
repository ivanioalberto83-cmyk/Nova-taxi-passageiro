package com.example

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import com.example.viewmodel.UserProfileViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class UserProfileTest {

    private lateinit var profileViewModel: UserProfileViewModel

    @Before
    fun setUp() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        profileViewModel = UserProfileViewModel(app)
    }

    @Test
    fun testDefaultUserProfile() {
        val profile = profileViewModel.userProfile.value
        assertEquals("Ivânio Alberto", profile.name)
        assertEquals("+244 923 456 789", profile.phoneNumber)
        assertEquals("ivanioalberto83@gmail.com", profile.email)
        assertNull(profile.photoUri)
        assertTrue(profile.rating > 4.9)
    }

    @Test
    fun testSaveValidProfile() {
        val success = profileViewModel.saveProfile(
            name = "Novo Nome Alberto",
            phoneNumber = "+244 912 345 678",
            email = "novo.email@gmail.com"
        )
        assertTrue(success)

        val updated = profileViewModel.userProfile.value
        assertEquals("Novo Nome Alberto", updated.name)
        assertEquals("+244 912 345 678", updated.phoneNumber)
        assertEquals("novo.email@gmail.com", updated.email)
    }

    @Test
    fun testRejectBlankProfileFields() {
        val blankNameSuccess = profileViewModel.saveProfile(
            name = "   ",
            phoneNumber = "+244 923 456 789",
            email = "test@example.com"
        )
        assertFalse("Não deve salvar nome vazio", blankNameSuccess)

        val blankPhoneSuccess = profileViewModel.saveProfile(
            name = "Nome Valido",
            phoneNumber = "",
            email = "test@example.com"
        )
        assertFalse("Não deve salvar telefone vazio", blankPhoneSuccess)
    }

    @Test
    fun testUpdateAndRemovePhoto() {
        val mockUri = "content://media/external/images/media/42"
        profileViewModel.updatePhotoUri(mockUri)

        assertEquals(mockUri, profileViewModel.userProfile.value.photoUri)

        profileViewModel.removePhoto()
        assertNull(profileViewModel.userProfile.value.photoUri)
    }
}
