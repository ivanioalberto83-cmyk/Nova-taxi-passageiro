package com.example

import com.example.model.FareEstimate
import com.example.model.RideStatus
import com.example.model.ServiceType
import com.example.model.TrafficCondition
import com.example.util.LuandaLocations
import com.example.viewmodel.RideHistoryViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class RideHistoryTest {

    private lateinit var historyViewModel: RideHistoryViewModel

    @Before
    fun setUp() {
        historyViewModel = RideHistoryViewModel()
    }

    @Test
    fun testInitialHistoryLoadsWithRides() {
        val state = historyViewModel.uiState.value
        assertTrue("History should have initial rides loaded", state.rides.isNotEmpty())
        assertEquals(5, state.totalRidesCount)
        assertTrue("Total spent should be positive", state.totalSpentAoa > 0.0)
    }

    @Test
    fun testFilterByServiceType() {
        historyViewModel.setServiceFilter(ServiceType.TAXI)
        var state = historyViewModel.uiState.value
        assertEquals(ServiceType.TAXI, state.selectedFilter)
        assertTrue("All filtered items must be TAXI", state.filteredRides.all { it.serviceType == ServiceType.TAXI })

        historyViewModel.setServiceFilter(ServiceType.BIKE)
        state = historyViewModel.uiState.value
        assertEquals(ServiceType.BIKE, state.selectedFilter)
        assertTrue("All filtered items must be BIKE", state.filteredRides.all { it.serviceType == ServiceType.BIKE })

        historyViewModel.setServiceFilter(ServiceType.DELIVERY)
        state = historyViewModel.uiState.value
        assertEquals(ServiceType.DELIVERY, state.selectedFilter)
        assertTrue("All filtered items must be DELIVERY", state.filteredRides.all { it.serviceType == ServiceType.DELIVERY })

        // Clear filter
        historyViewModel.setServiceFilter(null)
        state = historyViewModel.uiState.value
        assertNull(state.selectedFilter)
        assertEquals(5, state.filteredRides.size)
    }

    @Test
    fun testRecordNewRideIncreasesCountAndPrepends() {
        val initialCount = historyViewModel.uiState.value.rides.size
        val origin = LuandaLocations.defaultOrigin
        val destination = LuandaLocations.defaultDestination

        val mockEstimate = FareEstimate(
            serviceType = ServiceType.TAXI,
            straightLineDistanceKm = 5.4,
            roadDistanceKm = 7.0,
            estimatedDurationMinutes = 20,
            baseFareAoa = 600.0,
            distanceFareAoa = 2450.0,
            timeFareAoa = 800.0,
            trafficCondition = TrafficCondition.NORMAL,
            surgeMultiplier = 1.0,
            subtotalAoa = 3850.0,
            isMinimumFareApplied = false,
            totalFareAoa = 3850.0
        )

        historyViewModel.recordNewRide(
            serviceType = ServiceType.TAXI,
            origin = origin,
            destination = destination,
            estimate = mockEstimate
        )

        val newState = historyViewModel.uiState.value
        assertEquals(initialCount + 1, newState.totalRidesCount)
        assertEquals(initialCount + 1, newState.rides.size)
        assertEquals(origin.name, newState.rides.first().origin.name)
        assertEquals(destination.name, newState.rides.first().destination.name)
        assertEquals(3850.0, newState.rides.first().fareAoa, 0.01)
        assertEquals(RideStatus.COMPLETED, newState.rides.first().status)
    }
}
