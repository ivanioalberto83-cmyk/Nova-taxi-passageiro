package com.example

import com.example.model.DriverRideRequest
import com.example.model.ServiceType
import com.example.viewmodel.DriverViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class DriverViewModelTest {

    private lateinit var driverViewModel: DriverViewModel

    @Before
    fun setUp() {
        driverViewModel = DriverViewModel()
    }

    @Test
    fun testInitialDriverState() {
        val state = driverViewModel.uiState.value
        assertFalse("O motorista deve começar offline por padrão", state.isOnline)
        assertEquals("Bernardo Kiala", state.driverName)
        assertEquals("Toyota Corolla 2021", state.vehicleModel)
        assertNull("Não deve haver chamada pendente inicialmente", state.incomingRequest)
        assertNull("Não deve haver corrida ativa inicialmente", state.activeAcceptedRide)
        assertTrue("Deve aceitar Táxi inicialmente", state.acceptedServices.contains(ServiceType.TAXI))
        assertTrue("Deve aceitar Bike inicialmente", state.acceptedServices.contains(ServiceType.BIKE))
        assertTrue("Deve aceitar Entrega inicialmente", state.acceptedServices.contains(ServiceType.DELIVERY))
    }

    @Test
    fun testToggleOnlineOffline() {
        driverViewModel.toggleOnline()
        var state = driverViewModel.uiState.value
        assertTrue("Motorista deve ficar online", state.isOnline)

        driverViewModel.toggleOnline()
        state = driverViewModel.uiState.value
        assertFalse("Motorista deve voltar a ficar offline", state.isOnline)
        assertNull("Ao ficar offline, chamadas pendentes devem ser limpas", state.incomingRequest)
    }

    @Test
    fun testToggleServicePreferences() {
        // Inicialmente contém TAXI, BIKE, DELIVERY
        driverViewModel.toggleServicePreference(ServiceType.BIKE)
        var state = driverViewModel.uiState.value
        assertFalse("Bike deve ter sido removida", state.acceptedServices.contains(ServiceType.BIKE))
        assertTrue("Táxi continua ativo", state.acceptedServices.contains(ServiceType.TAXI))
        assertTrue("Entrega continua ativa", state.acceptedServices.contains(ServiceType.DELIVERY))

        // Adicionar Bike de volta
        driverViewModel.toggleServicePreference(ServiceType.BIKE)
        state = driverViewModel.uiState.value
        assertTrue("Bike deve voltar a estar ativa", state.acceptedServices.contains(ServiceType.BIKE))

        // Remover TAXI e BIKE para sobrar apenas DELIVERY
        driverViewModel.toggleServicePreference(ServiceType.TAXI)
        driverViewModel.toggleServicePreference(ServiceType.BIKE)
        state = driverViewModel.uiState.value
        assertEquals(1, state.acceptedServices.size)
        assertTrue(state.acceptedServices.contains(ServiceType.DELIVERY))

        // Tentar remover DELIVERY (última restante) não deve permitir esvaziar tudo
        driverViewModel.toggleServicePreference(ServiceType.DELIVERY)
        state = driverViewModel.uiState.value
        assertEquals(1, state.acceptedServices.size)
        assertTrue("Pelo menos uma modalidade deve permanecer ativa", state.acceptedServices.contains(ServiceType.DELIVERY))
    }

    @Test
    fun testAcceptIncomingRequestFlow() {
        // Simulando a aceitação
        val mockRequest = DriverRideRequest(
            id = "REQ-TEST-1",
            passengerName = "Marta Diniz",
            passengerRating = 4.9,
            serviceType = ServiceType.TAXI,
            pickupAddress = "Talatona",
            dropoffAddress = "Mutamba",
            distanceToPickupKm = 1.2,
            etaPickupMinutes = 5,
            tripDistanceKm = 10.0,
            estimatedEarningsAoa = 3500.0,
            paymentMethod = "Multicaixa Express"
        )

        // Inject request by reflection or by calling accept when null
        // Test accept when null:
        driverViewModel.acceptIncomingRequest()
        assertNull(driverViewModel.uiState.value.activeAcceptedRide)
    }
}
