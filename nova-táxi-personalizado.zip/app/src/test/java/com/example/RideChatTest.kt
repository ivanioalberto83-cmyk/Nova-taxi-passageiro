package com.example

import com.example.data.RideChatRepository
import com.example.model.MessageSenderRole
import com.example.viewmodel.RideChatViewModel
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class RideChatTest {

    private lateinit var chatViewModel: RideChatViewModel
    private val repository = RideChatRepository

    @Before
    fun setUp() {
        chatViewModel = RideChatViewModel()
        repository.resetForNewRide("Ivânio Alberto", "Bernardo Kiala")
    }

    @Test
    fun testInitialChatState() {
        val messages = repository.messages.value
        assertTrue("Deve haver mensagens iniciais na corrida", messages.isNotEmpty())

        val systemMsg = messages.find { it.senderRole == MessageSenderRole.SYSTEM }
        assertNotNull("Deve conter mensagem do sistema", systemMsg)

        val driverMsg = messages.find { it.senderRole == MessageSenderRole.DRIVER }
        assertNotNull("Deve conter mensagem de boas-vindas do motorista", driverMsg)
        assertTrue(driverMsg!!.senderName.contains("Bernardo Kiala"))
        assertTrue(driverMsg.text.contains("Ivânio Alberto"))
    }

    @Test
    fun testPassengerSendsMessage() {
        val initialSize = repository.messages.value.size

        repository.sendMessage(
            senderRole = MessageSenderRole.PASSENGER,
            senderName = "Ivânio Alberto",
            text = "Estou no portão principal do shopping",
            autoReply = false
        )

        val updated = repository.messages.value
        assertEquals(initialSize + 1, updated.size)

        val lastMsg = updated.last()
        assertEquals(MessageSenderRole.PASSENGER, lastMsg.senderRole)
        assertEquals("Estou no portão principal do shopping", lastMsg.text)
        assertEquals("Ivânio Alberto", lastMsg.senderName)
    }

    @Test
    fun testDriverSendsMessage() {
        val initialSize = repository.messages.value.size

        repository.sendMessage(
            senderRole = MessageSenderRole.DRIVER,
            senderName = "Bernardo Kiala",
            text = "Já estou a cerca de 100m com pisca ligado",
            autoReply = false
        )

        val updated = repository.messages.value
        assertEquals(initialSize + 1, updated.size)

        val lastMsg = updated.last()
        assertEquals(MessageSenderRole.DRIVER, lastMsg.senderRole)
        assertEquals("Já estou a cerca de 100m com pisca ligado", lastMsg.text)
    }

    @Test
    fun testMarkAsReadUpdatesUnreadCount() {
        // Envia mensagem do motorista sem ler
        repository.sendMessage(
            senderRole = MessageSenderRole.DRIVER,
            senderName = "Bernardo Kiala",
            text = "Nova mensagem não lida",
            autoReply = false
        )

        // Passageiro marca como lida
        repository.markAsRead(MessageSenderRole.PASSENGER)

        val messages = repository.messages.value
        val driverMessages = messages.filter { it.senderRole == MessageSenderRole.DRIVER }
        assertTrue("Todas as mensagens do motorista devem estar lidas pelo passageiro", driverMessages.all { it.isRead })
    }

    @Test
    fun testViewModelQuickSuggestions() {
        chatViewModel.onInputTextChanged("Mensagem teste")
        assertEquals("Mensagem teste", chatViewModel.inputText.value)

        chatViewModel.sendQuickSuggestion(
            role = MessageSenderRole.PASSENGER,
            senderName = "Ivânio Alberto",
            suggestion = "Estou no ponto de recolha"
        )

        val lastMsg = chatViewModel.messages.value.last()
        assertEquals("Estou no ponto de recolha", lastMsg.text)
        assertEquals(MessageSenderRole.PASSENGER, lastMsg.senderRole)
    }
}
