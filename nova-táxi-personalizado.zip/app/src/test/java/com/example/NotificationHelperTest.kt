package com.example

import android.app.NotificationManager
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.PassengerRideStage
import com.example.model.ServiceType
import com.example.util.NotificationHelper
import com.example.viewmodel.PassengerRideViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class NotificationHelperTest {

    private lateinit var context: Context
    private lateinit var notificationManager: NotificationManager

    @Before
    fun setUp() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        context = app
        shadowOf(app).grantPermissions(android.Manifest.permission.POST_NOTIFICATIONS)
        notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    @Test
    fun testNotificationChannelCreation() {
        NotificationHelper.createNotificationChannels(context)

        val channel = notificationManager.getNotificationChannel(NotificationHelper.CHANNEL_DRIVER_ARRIVAL_ID)
        assertNotNull("Canal de notificação de chegada do motorista deve existir", channel)
        assertEquals(NotificationManager.IMPORTANCE_HIGH, channel.importance)
        assertTrue("Canal deve ter vibração ativada", channel.shouldVibrate())
    }

    @Test
    fun testShowDriverArrivingNotification() {
        NotificationHelper.createNotificationChannels(context)

        val success = NotificationHelper.showDriverArrivingNotification(
            context = context,
            driverName = "Bernardo Kiala",
            vehicleInfo = "Toyota Corolla (LD-42-88-HA)",
            etaMinutes = 2,
            pickupAddress = "Aeroporto 4 de Fevereiro",
            rideId = "TEST-RIDE-01"
        )
        assertTrue("Notificação de aproximação deve ser enviada com sucesso", success)

        val shadowNm = shadowOf(notificationManager)
        val activeNotifications = shadowNm.allNotifications
        assertTrue("Deve haver pelo menos uma notificação ativa", activeNotifications.isNotEmpty())

        val notification = activeNotifications.find { it.channelId == NotificationHelper.CHANNEL_DRIVER_ARRIVAL_ID }
        assertNotNull("Notificação no canal de chegada do motorista deve existir", notification)

        val extras = notification!!.extras
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        assertTrue("Título deve conter 'chegar'", title.contains("chegar", ignoreCase = true))
        assertTrue("Texto deve conter o nome do motorista", text.contains("Bernardo Kiala"))
        assertTrue("Texto deve conter os minutos de espera", text.contains("2 min"))

        // Verifica a ação de Abrir Chat na notificação
        val actions = notification.actions
        assertNotNull("A notificação deve conter ações interativas", actions)
        val chatAction = actions.find { it.title.toString().contains("Chat", ignoreCase = true) }
        assertNotNull("Deve haver ação para Abrir Chat", chatAction)
    }

    @Test
    fun testShowDriverArrivedNotification() {
        NotificationHelper.createNotificationChannels(context)

        val success = NotificationHelper.showDriverArrivedNotification(
            context = context,
            driverName = "Bernardo Kiala",
            vehicleInfo = "Toyota Corolla (LD-42-88-HA)",
            pickupAddress = "Belas Shopping",
            rideId = "TEST-RIDE-02"
        )
        assertTrue("Notificação de chegada deve ser enviada com sucesso", success)

        val shadowNm = shadowOf(notificationManager)
        val notification = shadowNm.allNotifications.find { it.channelId == NotificationHelper.CHANNEL_DRIVER_ARRIVAL_ID }
        assertNotNull("Notificação de chegada deve existir", notification)

        val extras = notification!!.extras
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        assertTrue("Título deve indicar que o motorista chegou", title.contains("chegou", ignoreCase = true))
        assertTrue("Texto deve mencionar que está à espera no local", text.contains("espera", ignoreCase = true) || text.contains("Belas Shopping"))
    }

    @Test
    fun testCancelDriverArrivalNotification() {
        NotificationHelper.showDriverArrivedNotification(
            context = context,
            driverName = "Bernardo Kiala",
            vehicleInfo = "Toyota Corolla",
            pickupAddress = "Marginal de Luanda"
        )

        NotificationHelper.cancelDriverArrivalNotification(context)

        val shadowNm = shadowOf(notificationManager)
        val matchingNotifications = shadowNm.allNotifications.filter { it.channelId == NotificationHelper.CHANNEL_DRIVER_ARRIVAL_ID }
        assertTrue("Notificação deve ter sido cancelada e removida", matchingNotifications.isEmpty())
    }

    @Test
    fun testPassengerRideViewModelProgression() {
        val viewModel = PassengerRideViewModel()

        viewModel.startRide(
            context = context,
            originAddress = "Aeroporto 4 de Fevereiro",
            destAddress = "Marginal de Luanda",
            serviceType = ServiceType.TAXI,
            totalFareAoa = 3500.0
        )

        val initialRide = viewModel.uiState.value.activeRide
        assertNotNull("Deve iniciar corrida ativa", initialRide)
        assertEquals(PassengerRideStage.DRIVER_ASSIGNED, initialRide!!.stage)
        assertEquals(4, initialRide.etaMinutes)

        // Aciona chegada próxima (2 minutos)
        viewModel.triggerDriverArriving(context)
        val arrivingRide = viewModel.uiState.value.activeRide
        assertEquals(PassengerRideStage.DRIVER_ARRIVING, arrivingRide!!.stage)
        assertEquals(2, arrivingRide.etaMinutes)
        assertTrue(arrivingRide.arrivingNotificationSent)
        assertTrue(viewModel.uiState.value.inAppAlert!!.contains("chegar"))

        // Aciona chegada ao local
        viewModel.triggerDriverArrived(context)
        val arrivedRide = viewModel.uiState.value.activeRide
        assertEquals(PassengerRideStage.DRIVER_ARRIVED, arrivedRide!!.stage)
        assertEquals(0, arrivedRide.etaMinutes)
        assertTrue(arrivedRide.arrivedNotificationSent)
        assertTrue(viewModel.uiState.value.showArrivalCelebration)

        // Inicia viagem
        viewModel.startTripToDestination()
        val inTransitRide = viewModel.uiState.value.activeRide
        assertEquals(PassengerRideStage.IN_TRANSIT, inTransitRide!!.stage)

        // Conclui corrida
        viewModel.completeRide(context)
        assertNull("Corrida ativa deve ser limpa após conclusão", viewModel.uiState.value.activeRide)
    }
}
