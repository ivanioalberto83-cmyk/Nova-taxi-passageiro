package com.example

import com.example.model.ServiceType
import com.example.model.TrafficCondition
import com.example.viewmodel.FareCalculationViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class FareCalculationTest {

    private lateinit var viewModel: FareCalculationViewModel

    @Before
    fun setUp() {
        viewModel = FareCalculationViewModel()
    }

    @Test
    fun testTaxiFareCalculationAeroportoToMarginal() {
        // Aeroporto 4 de Fevereiro (-8.8584, 13.2312) to Marginal de Luanda (-8.8105, 13.2389) ~ 5.4 km straight line
        val estimate = viewModel.calculateEstimate(
            lat1 = -8.8584,
            lon1 = 13.2312,
            lat2 = -8.8105,
            lon2 = 13.2389,
            serviceType = ServiceType.TAXI,
            trafficCondition = TrafficCondition.NORMAL
        )

        // Verify distance calculations
        assertTrue("Straight line distance should be around 5.4 km", estimate.straightLineDistanceKm in 5.0..6.0)
        assertTrue("Road distance with 1.28 factor should be around 6.5 - 7.5 km", estimate.roadDistanceKm in 6.5..7.5)

        // Verify component costs
        assertEquals("Taxi base fare should be 600 AOA", 600.0, estimate.baseFareAoa, 0.01)
        assertTrue("Distance fare should be positive", estimate.distanceFareAoa > 2000.0)
        assertTrue("Duration should be around 15-25 minutes", estimate.estimatedDurationMinutes in 15..25)

        // Total fare should be greater than minimum fare of 1200 AOA
        assertTrue("Total fare should exceed minimum fare", estimate.totalFareAoa > ServiceType.TAXI.minimumFareAoa)
        assertTrue("Total fare should be a multiple of 50", estimate.totalFareAoa % 50.0 == 0.0)
    }

    @Test
    fun testBikeIsCheaperThanTaxi() {
        val lat1 = -8.8584
        val lon1 = 13.2312
        val lat2 = -8.8105
        val lon2 = 13.2389

        val taxiEstimate = viewModel.calculateEstimate(
            lat1 = lat1,
            lon1 = lon1,
            lat2 = lat2,
            lon2 = lon2,
            serviceType = ServiceType.TAXI,
            trafficCondition = TrafficCondition.NORMAL
        )

        val bikeEstimate = viewModel.calculateEstimate(
            lat1 = lat1,
            lon1 = lon1,
            lat2 = lat2,
            lon2 = lon2,
            serviceType = ServiceType.BIKE,
            trafficCondition = TrafficCondition.NORMAL
        )

        assertTrue(
            "Bike fare (${bikeEstimate.totalFareAoa} AOA) must be lower than Taxi fare (${taxiEstimate.totalFareAoa} AOA)",
            bikeEstimate.totalFareAoa < taxiEstimate.totalFareAoa
        )

        assertTrue(
            "Bike duration (${bikeEstimate.estimatedDurationMinutes} min) should be faster or equal to Taxi (${taxiEstimate.estimatedDurationMinutes} min)",
            bikeEstimate.estimatedDurationMinutes <= taxiEstimate.estimatedDurationMinutes
        )
    }

    @Test
    fun testMinimumFareAppliedForVeryShortTrips() {
        // Very short distance (< 100 meters)
        val lat1 = -8.8584
        val lon1 = 13.2312
        val lat2 = -8.8586
        val lon2 = 13.2313

        val taxiEstimate = viewModel.calculateEstimate(
            lat1 = lat1,
            lon1 = lon1,
            lat2 = lat2,
            lon2 = lon2,
            serviceType = ServiceType.TAXI,
            trafficCondition = TrafficCondition.NORMAL
        )

        assertEquals("Short trip Taxi must default to minimum fare 1200 AOA", 1200.0, taxiEstimate.totalFareAoa, 0.01)
        assertTrue("isMinimumFareApplied should be true", taxiEstimate.isMinimumFareApplied)

        val bikeEstimate = viewModel.calculateEstimate(
            lat1 = lat1,
            lon1 = lon1,
            lat2 = lat2,
            lon2 = lon2,
            serviceType = ServiceType.BIKE,
            trafficCondition = TrafficCondition.NORMAL
        )

        assertEquals("Short trip Bike must default to minimum fare 600 AOA", 600.0, bikeEstimate.totalFareAoa, 0.01)
        assertTrue("isMinimumFareApplied should be true for bike", bikeEstimate.isMinimumFareApplied)
    }

    @Test
    fun testPeakHourIncreasesFare() {
        val lat1 = -8.8584
        val lon1 = 13.2312
        val lat2 = -8.8105
        val lon2 = 13.2389

        val normalFare = viewModel.calculateEstimate(
            lat1 = lat1,
            lon1 = lon1,
            lat2 = lat2,
            lon2 = lon2,
            serviceType = ServiceType.TAXI,
            trafficCondition = TrafficCondition.NORMAL
        )

        val peakFare = viewModel.calculateEstimate(
            lat1 = lat1,
            lon1 = lon1,
            lat2 = lat2,
            lon2 = lon2,
            serviceType = ServiceType.TAXI,
            trafficCondition = TrafficCondition.HEAVY_TRAFFIC
        )

        assertTrue(
            "Peak hour fare (${peakFare.totalFareAoa}) must be strictly higher than normal fare (${normalFare.totalFareAoa})",
            peakFare.totalFareAoa > normalFare.totalFareAoa
        )
        assertTrue(
            "Peak hour duration (${peakFare.estimatedDurationMinutes}) must be higher due to traffic delay",
            peakFare.estimatedDurationMinutes > normalFare.estimatedDurationMinutes
        )
    }

    @Test
    fun testDeliveryFareCalculation() {
        val lat1 = -8.8584
        val lon1 = 13.2312
        val lat2 = -8.8105
        val lon2 = 13.2389

        val deliveryEstimate = viewModel.calculateEstimate(
            lat1 = lat1,
            lon1 = lon1,
            lat2 = lat2,
            lon2 = lon2,
            serviceType = ServiceType.DELIVERY,
            trafficCondition = TrafficCondition.NORMAL
        )

        assertEquals("Delivery base fare should be 400 AOA", 400.0, deliveryEstimate.baseFareAoa, 0.01)
        assertTrue("Delivery total fare should be >= minimum 800 AOA", deliveryEstimate.totalFareAoa >= 800.0)
        assertTrue("Delivery total fare should be multiple of 50 AOA", deliveryEstimate.totalFareAoa % 50.0 == 0.0)
    }
}
