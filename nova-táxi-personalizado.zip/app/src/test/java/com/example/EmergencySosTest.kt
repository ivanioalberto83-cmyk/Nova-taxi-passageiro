package com.example

import com.example.model.EmergencyContact
import com.example.util.EmergencyHelper
import org.junit.Assert.*
import org.junit.Test

class EmergencySosTest {

    @Test
    fun testBuildSosMessageWithRealTimeGpsCoordinates() {
        val lat = -8.8584
        val lng = 13.2312
        val accuracy = 5.0f
        val nearestPlace = "Aeroporto 4 de Fevereiro"

        val message = EmergencyHelper.buildSosMessage(
            latitude = lat,
            longitude = lng,
            accuracyMeters = accuracy,
            nearestPlaceName = nearestPlace
        )

        assertTrue("Message must contain SOS alert title", message.contains("ALERTA SOS - NOVA TÁXI ANGOLA"))
        assertTrue("Message must contain latitude", message.contains("-8.858400"))
        assertTrue("Message must contain longitude", message.contains("13.231200"))
        assertTrue("Message must contain accuracy", message.contains("±5 metros"))
        assertTrue("Message must contain landmark", message.contains("Aeroporto 4 de Fevereiro"))
        assertTrue("Message must contain Google Maps link", message.contains("https://maps.google.com/?q=-8.8584,13.2312"))
    }

    @Test
    fun testBuildSosMessageWithNullCoordinatesFallback() {
        val message = EmergencyHelper.buildSosMessage(
            latitude = null,
            longitude = null,
            accuracyMeters = null,
            nearestPlaceName = null
        )

        assertTrue("Message must contain SOS alert title", message.contains("ALERTA SOS - NOVA TÁXI ANGOLA"))
        assertTrue("Message must notify about Luanda reference", message.contains("Luanda, Angola"))
    }

    @Test
    fun testEmergencyContactDefaultValues() {
        val contact = EmergencyContact()
        assertEquals("+244923000112", contact.phone)
        assertFalse(contact.name.isBlank())

        val updated = contact.copy(phone = "+244912345678", name = "Familiar de Confiança")
        assertEquals("+244912345678", updated.phone)
        assertEquals("Familiar de Confiança", updated.name)
    }
}
