package com.example.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Papel do remetente da mensagem.
 */
enum class MessageSenderRole {
    PASSENGER,
    DRIVER,
    SYSTEM
}

/**
 * Modelo de dados para mensagens de chat em tempo real durante a corrida.
 */
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderRole: MessageSenderRole,
    val senderName: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
) {
    val formattedTime: String
        get() {
            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }
}
