package com.example.model

/**
 * Fases da corrida acompanhada pelo passageiro na aplicação NOVA Táxi.
 */
enum class PassengerRideStage(val label: String) {
    IDLE("Sem corrida ativa"),
    DRIVER_ASSIGNED("Motorista a caminho"),
    DRIVER_ARRIVING("Motorista a chegar ao local"),
    DRIVER_ARRIVED("Motorista no ponto de encontro"),
    IN_TRANSIT("Em viagem"),
    COMPLETED("Corrida concluída"),
    CANCELLED("Corrida cancelada")
}

/**
 * Estado detalhado de acompanhamento em tempo real da corrida para o passageiro.
 */
data class PassengerActiveRide(
    val rideId: String,
    val stage: PassengerRideStage = PassengerRideStage.DRIVER_ASSIGNED,
    val serviceType: ServiceType = ServiceType.TAXI,
    val originAddress: String,
    val destinationAddress: String,
    val totalFareAoa: Double,
    val driverName: String = "Bernardo Kiala",
    val driverPhone: String = "+244 923 456 789",
    val driverRating: Double = 4.96,
    val vehicleModel: String = "Toyota Corolla Branco",
    val vehiclePlate: String = "LD-42-88-HA",
    val etaMinutes: Int = 4,
    val distanceToPickupKm: Double = 1.8,
    val arrivingNotificationSent: Boolean = false,
    val arrivedNotificationSent: Boolean = false
) {
    val formattedFare: String
        get() = "${totalFareAoa.toInt()} Kz"

    val isArrivingSoon: Boolean
        get() = stage == PassengerRideStage.DRIVER_ARRIVING

    val hasArrived: Boolean
        get() = stage == PassengerRideStage.DRIVER_ARRIVED
}
