package com.example.model

/**
 * Tipos de serviço disponíveis na plataforma NOVA Táxi em Luanda, Angola.
 * Contém os parâmetros tarifários oficiais em Kwanzas (AOA).
 */
enum class ServiceType(
    val id: String,
    val title: String,
    val subtitle: String,
    val baseFareAoa: Double,
    val ratePerKmAoa: Double,
    val ratePerMinuteAoa: Double,
    val minimumFareAoa: Double,
    val averageSpeedKmh: Double,
    val capacitySeats: Int
) {
    TAXI(
        id = "TAXI",
        title = "Táxi",
        subtitle = "Carro confortável, AC, até 4 pessoas",
        baseFareAoa = 600.0,
        ratePerKmAoa = 350.0,
        ratePerMinuteAoa = 40.0,
        minimumFareAoa = 1200.0,
        averageSpeedKmh = 22.0,
        capacitySeats = 4
    ),
    BIKE(
        id = "BIKE",
        title = "Bike",
        subtitle = "Mais ágil no trânsito, 1 passageiro",
        baseFareAoa = 300.0,
        ratePerKmAoa = 200.0,
        ratePerMinuteAoa = 20.0,
        minimumFareAoa = 600.0,
        averageSpeedKmh = 30.0,
        capacitySeats = 1
    ),
    DELIVERY(
        id = "DELIVERY",
        title = "Entrega",
        subtitle = "Envio de encomendas e documentos em Luanda",
        baseFareAoa = 400.0,
        ratePerKmAoa = 220.0,
        ratePerMinuteAoa = 25.0,
        minimumFareAoa = 800.0,
        averageSpeedKmh = 26.0,
        capacitySeats = 0
    )
}
