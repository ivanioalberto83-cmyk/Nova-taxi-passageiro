package com.example.model

/**
 * Modelo de dados com as informações de perfil do utilizador da NOVA Táxi.
 */
data class UserProfile(
    val name: String = "Ivânio Alberto",
    val phoneNumber: String = "+244 923 456 789",
    val email: String = "ivanioalberto83@gmail.com",
    val photoUri: String? = null,
    val rating: Double = 4.97,
    val totalRidesAsPassenger: Int = 24,
    val memberSince: String = "Outubro de 2024",
    val preferredPaymentMethod: String = "Multicaixa Express"
)
