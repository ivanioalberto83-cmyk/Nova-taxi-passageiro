package com.example.model

/**
 * Representa o contacto de segurança/emergência pré-definido do utilizador.
 */
data class EmergencyContact(
    val name: String = "Centro de Apoio & Emergência",
    val phone: String = "+244923000112",
    val relationship: String = "Segurança NOVA Táxi / Familiar"
)
