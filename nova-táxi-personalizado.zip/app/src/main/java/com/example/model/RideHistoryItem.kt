package com.example.model

import java.text.NumberFormat
import java.util.Locale

enum class RideStatus(val label: String) {
    COMPLETED("Concluída"),
    CANCELLED("Cancelada"),
    IN_PROGRESS("Em Curso")
}

/**
 * Representa o registo histórico de uma corrida realizada na NOVA Táxi em Luanda.
 */
data class RideHistoryItem(
    val id: String,
    val serviceType: ServiceType,
    val origin: LuandaPlace,
    val destination: LuandaPlace,
    val distanceKm: Double,
    val durationMinutes: Int,
    val fareAoa: Double,
    val dateFormatted: String,
    val timestamp: Long,
    val status: RideStatus = RideStatus.COMPLETED,
    val driverName: String,
    val driverRating: Double = 4.9,
    val vehicleModel: String,
    val vehiclePlate: String,
    val paymentMethod: String = "Multicaixa Express"
) {
    val formattedFare: String
        get() {
            val nf = NumberFormat.getIntegerInstance(Locale("pt", "AO"))
            return "${nf.format(fareAoa.toInt()).replace(',', '.')} Kz"
        }

    val formattedDistance: String
        get() = String.format(Locale.US, "%.1f km", distanceKm)

    val formattedDuration: String
        get() = "$durationMinutes min"
}
