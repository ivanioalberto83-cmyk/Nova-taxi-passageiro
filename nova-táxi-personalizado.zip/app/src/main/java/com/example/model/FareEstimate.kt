package com.example.model

import java.text.NumberFormat
import java.util.Locale

/**
 * Fatores de trânsito típicos de Luanda (Hora de ponta na Deolinda Rodrigues, Estrada de Catete, etc.)
 */
enum class TrafficCondition(
    val label: String,
    val speedMultiplier: Double, // Redução de velocidade no tráfego
    val surgeMultiplier: Double  // Multiplicador da tarifa por procura/trânsito
) {
    NORMAL("Trânsito Normal", 1.0, 1.0),
    MODERATE("Tráfego Moderado", 0.85, 1.10),
    HEAVY_TRAFFIC("Hora de Ponta", 0.65, 1.25)
}

/**
 * Resultado detalhado da estimativa de tarifa calculada para uma corrida.
 */
data class FareEstimate(
    val serviceType: ServiceType,
    val straightLineDistanceKm: Double,
    val roadDistanceKm: Double,
    val estimatedDurationMinutes: Int,
    val baseFareAoa: Double,
    val distanceFareAoa: Double,
    val timeFareAoa: Double,
    val trafficCondition: TrafficCondition,
    val surgeMultiplier: Double,
    val subtotalAoa: Double,
    val isMinimumFareApplied: Boolean,
    val totalFareAoa: Double
) {
    /**
     * Formatação em Kwanzas angolanos (ex: "2.450 Kz")
     */
    val formattedTotalFare: String
        get() = "${formatNumber(totalFareAoa.toInt())} Kz"

    val formattedBaseFare: String
        get() = "${formatNumber(baseFareAoa.toInt())} Kz"

    val formattedDistanceFare: String
        get() = "${formatNumber(distanceFareAoa.toInt())} Kz"

    val formattedTimeFare: String
        get() = "${formatNumber(timeFareAoa.toInt())} Kz"

    val formattedDistance: String
        get() = String.format(Locale.US, "%.1f km", roadDistanceKm)

    val formattedDuration: String
        get() = "$estimatedDurationMinutes min"

    companion object {
        private fun formatNumber(value: Int): String {
            val nf = NumberFormat.getIntegerInstance(Locale("pt", "AO"))
            return nf.format(value).replace(',', '.')
        }
    }
}
