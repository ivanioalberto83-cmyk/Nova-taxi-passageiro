package com.example.model

/**
 * Modos de operação da aplicação NOVA Táxi.
 */
enum class AppMode(val label: String) {
    PASSENGER("Passageiro"),
    DRIVER("Motorista")
}

/**
 * Representa um pedido de corrida recebido pelo motorista no painel de disponibilidade.
 */
data class DriverRideRequest(
    val id: String,
    val passengerName: String,
    val passengerRating: Double = 4.9,
    val serviceType: ServiceType,
    val pickupAddress: String,
    val dropoffAddress: String,
    val distanceToPickupKm: Double,
    val etaPickupMinutes: Int,
    val tripDistanceKm: Double,
    val estimatedEarningsAoa: Double,
    val paymentMethod: String = "Multicaixa Express"
) {
    val formattedEarnings: String
        get() = "${estimatedEarningsAoa.toInt()} Kz"
}
