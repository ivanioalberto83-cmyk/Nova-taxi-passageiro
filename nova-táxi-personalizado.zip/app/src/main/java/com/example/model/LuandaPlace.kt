package com.example.model

/**
 * Representa um local geográfico de referência em Luanda, Angola.
 */
data class LuandaPlace(
    val id: String,
    val name: String,
    val district: String,
    val lat: Double,
    val lng: Double,
    val address: String = "$name, $district, Luanda"
)
