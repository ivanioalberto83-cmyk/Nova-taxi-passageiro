package com.example.util

data class GeoPoint(
    val lat: Double,
    val lng: Double
)
