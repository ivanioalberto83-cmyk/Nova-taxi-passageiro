package com.example.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

/**
 * Utilitário responsável pelo envio e gestão de notificações locais da NOVA Táxi,
 * em especial para alertar o passageiro quando o motorista estiver a chegar
 * ou tiver chegado ao local de partida.
 */
object NotificationHelper {

    const val CHANNEL_DRIVER_ARRIVAL_ID = "nova_taxi_driver_arrival_channel"
    const val NOTIFICATION_ID_DRIVER_ARRIVAL = 7001
    const val EXTRA_OPEN_CHAT = "EXTRA_OPEN_CHAT"
    const val EXTRA_RIDE_ID = "EXTRA_RIDE_ID"

    /**
     * Inicializa os canais de notificação no Android 8.0+ (API 26+).
     */
    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Avisos de Chegada da Corrida"
            val descriptionText = "Alertas locais quando o motorista estiver próximo ou chegar ao local de partida."
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_DRIVER_ARRIVAL_ID, name, importance).apply {
                description = descriptionText
                enableLights(true)
                lightColor = Color.parseColor("#FF6D00") // Laranja NOVA Táxi
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 150, 300)
            }

            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * Verifica se a aplicação possui permissão para emitir notificações locais.
     */
    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            NotificationManagerCompat.from(context).areNotificationsEnabled()
        }
    }

    /**
     * Dispara notificação local alertando que o motorista está a chegar ao local de partida (ex: 2 min).
     */
    fun showDriverArrivingNotification(
        context: Context,
        driverName: String,
        vehicleInfo: String,
        etaMinutes: Int,
        pickupAddress: String,
        rideId: String = "NOVA-RIDE-1"
    ): Boolean {
        createNotificationChannels(context)

        if (!hasNotificationPermission(context)) {
            return false
        }

        // Intent principal ao tocar na notificação (abre a aplicação)
        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_RIDE_ID, rideId)
            putExtra(EXTRA_OPEN_CHAT, false)
        }
        val mainPendingIntent = PendingIntent.getActivity(
            context,
            101,
            mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Intent da Ação: Abrir Chat direto com o motorista
        val chatIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_RIDE_ID, rideId)
            putExtra(EXTRA_OPEN_CHAT, true)
        }
        val chatPendingIntent = PendingIntent.getActivity(
            context,
            102,
            chatIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val title = "🚕 O seu motorista está a chegar!"
        val shortContent = "$driverName está a $etaMinutes min de $pickupAddress."
        val expandedContent = "O motorista $driverName ($vehicleInfo) está a aproximadamente $etaMinutes minuto(s) do seu local de partida ($pickupAddress). Por favor, aproxime-se do ponto de encontro."

        val builder = NotificationCompat.Builder(context, CHANNEL_DRIVER_ARRIVAL_ID)
            .setSmallIcon(R.drawable.ic_notification_taxi)
            .setContentTitle(title)
            .setContentText(shortContent)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expandedContent))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setContentIntent(mainPendingIntent)
            .setAutoCancel(true)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 300, 150, 300))
            .setColor(Color.parseColor("#FF6D00"))
            .addAction(
                android.R.drawable.ic_menu_send,
                "Abrir Chat",
                chatPendingIntent
            )

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_DRIVER_ARRIVAL, builder.build())
            return true
        } catch (e: SecurityException) {
            return false
        }
    }

    /**
     * Dispara notificação local alertando que o motorista chegou ao ponto de recolha.
     */
    fun showDriverArrivedNotification(
        context: Context,
        driverName: String,
        vehicleInfo: String,
        pickupAddress: String,
        rideId: String = "NOVA-RIDE-1"
    ): Boolean {
        createNotificationChannels(context)

        if (!hasNotificationPermission(context)) {
            return false
        }

        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_RIDE_ID, rideId)
            putExtra(EXTRA_OPEN_CHAT, false)
        }
        val mainPendingIntent = PendingIntent.getActivity(
            context,
            201,
            mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val chatIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_RIDE_ID, rideId)
            putExtra(EXTRA_OPEN_CHAT, true)
        }
        val chatPendingIntent = PendingIntent.getActivity(
            context,
            202,
            chatIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val title = "📍 O motorista chegou ao local de partida!"
        val shortContent = "$driverName está à sua espera em $pickupAddress."
        val expandedContent = "O motorista $driverName chegou com a viatura $vehicleInfo ao ponto de partida em $pickupAddress e está a aguardar o seu embarque."

        val builder = NotificationCompat.Builder(context, CHANNEL_DRIVER_ARRIVAL_ID)
            .setSmallIcon(R.drawable.ic_notification_taxi)
            .setContentTitle(title)
            .setContentText(shortContent)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expandedContent))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setContentIntent(mainPendingIntent)
            .setAutoCancel(true)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 400, 200, 400, 200, 400))
            .setColor(Color.parseColor("#1B5E20")) // Verde de chegada
            .addAction(
                android.R.drawable.ic_menu_send,
                "Abrir Chat",
                chatPendingIntent
            )

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_DRIVER_ARRIVAL, builder.build())
            return true
        } catch (e: SecurityException) {
            return false
        }
    }

    /**
     * Cancela e limpa a notificação de chegada da corrida.
     */
    fun cancelDriverArrivalNotification(context: Context) {
        try {
            NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID_DRIVER_ARRIVAL)
        } catch (_: Exception) {
        }
    }
}
