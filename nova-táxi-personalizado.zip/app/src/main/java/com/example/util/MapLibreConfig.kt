package com.example.util

import android.content.Context
import android.util.Log
import org.maplibre.android.MapLibre
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.Style

object MapLibreConfig {

    const val OPENFREEMAP_LIBERTY = "https://tiles.openfreemap.org/styles/liberty"
    const val OPENFREEMAP_BRIGHT = "https://tiles.openfreemap.org/styles/bright"
    const val OPENFREEMAP_POSITRON = "https://tiles.openfreemap.org/styles/positron"
    const val MAPLIBRE_DEMO_STYLE = "https://demotiles.maplibre.org/style.json"

    const val DEFAULT_STYLE = OPENFREEMAP_LIBERTY

    const val ATTRIBUTION_TEXT = "© OpenStreetMap contributors • OpenFreeMap"
    const val ATTRIBUTION_URL = "https://www.openstreetmap.org/copyright"

    val LUANDA_CENTER = LatLng(-8.8383, 13.2343)
    const val DEFAULT_ZOOM = 13.0

    private var isInitialized = false

    fun initialize(context: Context) {
        if (isInitialized && MapLibre.hasInstance()) return
        try {
            val appContext = context.applicationContext ?: context
            MapLibre.getInstance(appContext, null, org.maplibre.android.WellKnownTileServer.MapLibre)
            isInitialized = true
            Log.i("MapLibreConfig", "MapLibre Native inicializado com sucesso.")
        } catch (e: Throwable) {
            Log.e("MapLibreConfig", "Erro ao inicializar MapLibre: ${e.message}", e)
        }
    }

    fun createStyleBuilder(styleUrl: String = DEFAULT_STYLE): Style.Builder {
        return Style.Builder().fromUri(styleUrl)
    }
}
