package com.example.util

import com.example.model.LuandaPlace
import kotlin.math.*

object LuandaLocations {

    val places = listOf(
        LuandaPlace("aeroporto", "Aeroporto 4 de Fevereiro", "Maianga", -8.8584, 13.2312),
        LuandaPlace("marginal", "Marginal de Luanda / Baía", "Ingombota", -8.8105, 13.2389),
        LuandaPlace("talatona", "Belas Shopping", "Talatona", -8.9189, 13.1812),
        LuandaPlace("ilha", "Ilha do Cabo (Chicala)", "Ingombota", -8.7889, 13.2514),
        LuandaPlace("kilamba", "Centralidade do Kilamba", "Belas", -8.9950, 13.2450),
        LuandaPlace("viana", "Viana Estalagem", "Viana", -8.9056, 13.3719),
        LuandaPlace("cazenga", "Marco Histórico do Cazenga", "Cazenga", -8.8250, 13.2890),
        LuandaPlace("mutamba", "Largo da Mutamba", "Ingombota", -8.8145, 13.2325),
        LuandaPlace("alvalade", "Praça de Alvalade", "Maianga", -8.8350, 13.2280),
        LuandaPlace("maculusso", "Igreja Sagrada Família", "Maculusso", -8.8230, 13.2370)
    )

    val defaultOrigin = places[0]
    val defaultDestination = places[1]

    fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0 // Raio da Terra em km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2.0) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2.0)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return (r * c * 100.0).roundToInt() / 100.0
    }

    fun findNearestPlace(lat: Double, lng: Double): LuandaPlace {
        return places.minByOrNull { calculateDistanceKm(lat, lng, it.lat, it.lng) } ?: defaultOrigin
    }
}
