package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object EmergencyHelper {

    /**
     * Gera a mensagem padronizada de emergência SOS com localização GPS em tempo real.
     */
    fun buildSosMessage(
        latitude: Double?,
        longitude: Double?,
        accuracyMeters: Float?,
        nearestPlaceName: String?
    ): String {
        val timeStr = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
        return buildString {
            append("🚨 ALERTA SOS - NOVA TÁXI ANGOLA 🚨\n")
            append("Estou em situação de emergência e preciso de assistência imediata!\n\n")

            if (latitude != null && longitude != null) {
                append("📍 Coordenadas GPS:\n")
                append(String.format(Locale.US, "Lat: %.6f, Long: %.6f\n", latitude, longitude))
                if (accuracyMeters != null) {
                    append("Precisão: ±${accuracyMeters.toInt()} metros\n")
                }
                if (!nearestPlaceName.isNullOrBlank()) {
                    append("Ponto de referência: $nearestPlaceName, Luanda\n")
                }
                append("\n🗺️ Ver no Google Maps:\n")
                append("https://maps.google.com/?q=$latitude,$longitude\n")
            } else {
                append("📍 Sinal GPS a ser localizado. Local de referência: Luanda, Angola.\n")
            }

            append("\nHora do alerta: $timeStr")
        }
    }

    /**
     * Dispara o envio de SMS com o texto e o contacto pré-definido via Intent nativa segura.
     */
    fun sendSosSms(
        context: Context,
        phoneNumber: String,
        message: String
    ): Boolean {
        return try {
            val uri = Uri.parse("smsto:${Uri.encode(phoneNumber)}")
            val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                putExtra("sms_body", message)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            // Fallback caso o dispositivo não suporte smsto direto
            try {
                val fallbackIntent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("sms:${Uri.encode(phoneNumber)}")
                    putExtra("sms_body", message)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(fallbackIntent)
                true
            } catch (ex: Exception) {
                Toast.makeText(context, "Erro ao abrir aplicação de SMS: ${ex.localizedMessage}", Toast.LENGTH_LONG).show()
                false
            }
        }
    }

    /**
     * Inicia chamada direta para o número de emergência nacional (111) ou contacto predefinido.
     */
    fun dialEmergency(context: Context, phoneNumber: String = "111") {
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Não foi possível abrir o discador.", Toast.LENGTH_SHORT).show()
        }
    }
}
