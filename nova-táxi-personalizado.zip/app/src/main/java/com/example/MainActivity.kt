package com.example

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.zIndex
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.RideChatRepository
import com.example.model.AppMode
import com.example.model.EmergencyContact
import com.example.model.FareEstimate
import com.example.model.MessageSenderRole
import com.example.model.ServiceType
import com.example.ui.components.DriverDashboardView
import com.example.ui.components.FareEstimateCard
import com.example.ui.components.FloatingSosButton
import com.example.ui.components.LocationStatusCard
import com.example.ui.components.MapLibreNativeView
import com.example.ui.components.RideChatScreen
import com.example.ui.components.RideHistoryModal
import com.example.ui.components.ServiceBottomNavigationBar
import com.example.ui.components.SosEmergencyDialog
import com.example.ui.components.UserProfileScreen
import com.example.ui.theme.*
import com.example.util.EmergencyHelper
import com.example.util.LuandaLocations
import com.example.util.MapLibreConfig
import com.example.viewmodel.DriverViewModel
import com.example.viewmodel.FareCalculationViewModel
import com.example.viewmodel.RideChatViewModel
import com.example.viewmodel.RideHistoryViewModel
import android.content.Intent
import android.os.Build
import com.example.ui.components.ActiveRideTrackerCard
import com.example.ui.components.DriverArrivalAlertBanner
import com.example.util.NotificationHelper
import com.example.viewmodel.PassengerRideViewModel
import com.example.viewmodel.UserLocationViewModel
import com.example.viewmodel.UserProfileViewModel

class MainActivity : ComponentActivity() {

    private val locationViewModel: UserLocationViewModel by viewModels()
    private val fareViewModel: FareCalculationViewModel by viewModels()
    private val historyViewModel: RideHistoryViewModel by viewModels()
    private val driverViewModel: DriverViewModel by viewModels()
    private val profileViewModel: UserProfileViewModel by viewModels()
    private val chatViewModel: RideChatViewModel by viewModels()
    private val passengerRideViewModel: PassengerRideViewModel by viewModels()

    private val openChatFromNotification = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibreConfig.initialize(applicationContext)
        NotificationHelper.createNotificationChannels(applicationContext)

        if (intent?.getBooleanExtra(NotificationHelper.EXTRA_OPEN_CHAT, false) == true) {
            openChatFromNotification.value = true
        }

        enableEdgeToEdge()

        setContent {
            NovaTaxiTheme {
                NovaTaxiMainScreen(
                    locationViewModel = locationViewModel,
                    fareViewModel = fareViewModel,
                    historyViewModel = historyViewModel,
                    driverViewModel = driverViewModel,
                    profileViewModel = profileViewModel,
                    chatViewModel = chatViewModel,
                    passengerRideViewModel = passengerRideViewModel,
                    openChatRequested = openChatFromNotification.value,
                    onChatOpened = { openChatFromNotification.value = false }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(NotificationHelper.EXTRA_OPEN_CHAT, false)) {
            openChatFromNotification.value = true
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaTaxiMainScreen(
    locationViewModel: UserLocationViewModel,
    fareViewModel: FareCalculationViewModel,
    historyViewModel: RideHistoryViewModel,
    driverViewModel: DriverViewModel,
    profileViewModel: UserProfileViewModel,
    chatViewModel: RideChatViewModel,
    passengerRideViewModel: PassengerRideViewModel,
    openChatRequested: Boolean = false,
    onChatOpened: () -> Unit = {}
) {
    val context = LocalContext.current
    val locationState by locationViewModel.uiState.collectAsStateWithLifecycle()
    val fareState by fareViewModel.uiState.collectAsStateWithLifecycle()
    val historyState by historyViewModel.uiState.collectAsStateWithLifecycle()
    val driverState by driverViewModel.uiState.collectAsStateWithLifecycle()
    val profileState by profileViewModel.userProfile.collectAsStateWithLifecycle()
    val passengerRideState by passengerRideViewModel.uiState.collectAsStateWithLifecycle()
    val unreadForPassenger by chatViewModel.unreadCountForPassenger.collectAsStateWithLifecycle()
    val unreadForDriver by chatViewModel.unreadCountForDriver.collectAsStateWithLifecycle()

    var appMode by remember { mutableStateOf(AppMode.PASSENGER) }
    var showProfileScreen by remember { mutableStateOf(false) }
    var showChatScreen by remember { mutableStateOf(false) }
    var showGpsCard by remember { mutableStateOf(false) }
    var showHistoryModal by remember { mutableStateOf(false) }
    var showSosDialog by remember { mutableStateOf(false) }
    var emergencyContact by remember { mutableStateOf(EmergencyContact()) }
    var activeOrderEstimate by remember { mutableStateOf<FareEstimate?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    // Notificação de abertura direta do chat via intent
    LaunchedEffect(openChatRequested) {
        if (openChatRequested) {
            showChatScreen = true
            onChatOpened()
        }
    }

    // Launcher de permissão de Notificações Locais (Android 13+ / API 33+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "Notificações locais ativadas com sucesso!", Toast.LENGTH_SHORT).show()
        }
    }

    // Launcher de permissão de GPS em runtime
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        val isGranted = fineGranted || coarseGranted
        locationViewModel.onPermissionResult(isGranted, context)
        if (isGranted) {
            Toast.makeText(context, "GPS ativado com sucesso!", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        locationViewModel.initialize(context)
        // Solicita permissões de GPS
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
        // Solicita permissão de Notificações Locais se Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!NotificationHelper.hasNotificationPermission(context)) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Atualiza a origem automaticamente se o passageiro quiser usar o GPS
    val useGpsAsOrigin: () -> Unit = {
        val lat = locationState.latitude
        val lng = locationState.longitude
        if (lat != null && lng != null) {
            val nearest = locationState.nearestPlace?.name ?: "Minha Localização"
            fareViewModel.setOriginFromGps(lat, lng, nearest)
            Toast.makeText(context, "Origem definida para a sua posição GPS!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Aguardando sinal GPS...", Toast.LENGTH_SHORT).show()
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    if (showProfileScreen) {
        UserProfileScreen(
            userProfile = profileState,
            onSaveProfile = { name, phone, email ->
                profileViewModel.saveProfile(name, phone, email)
            },
            onUpdatePhoto = { uriString ->
                profileViewModel.updatePhotoUri(uriString)
            },
            onNavigateBack = { showProfileScreen = false }
        )
    } else if (showChatScreen) {
        val otherName = if (appMode == AppMode.PASSENGER) {
            "Bernardo Kiala (Motorista)"
        } else {
            driverState.activeAcceptedRide?.passengerName ?: profileState.name
        }
        val otherSubtitle = if (appMode == AppMode.PASSENGER) {
            "Toyota Corolla • LD-42-88-HA"
        } else {
            "Passageiro NOVA Táxi"
        }
        RideChatScreen(
            currentRole = if (appMode == AppMode.PASSENGER) MessageSenderRole.PASSENGER else MessageSenderRole.DRIVER,
            currentUserName = if (appMode == AppMode.PASSENGER) profileState.name else "Bernardo Kiala",
            otherPartyName = otherName,
            otherPartySubtitle = otherSubtitle,
            chatViewModel = chatViewModel,
            onNavigateBack = { showChatScreen = false }
        )
    } else {
        Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = NovaOrangePrimary,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.LocalTaxi,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "NOVA Táxi",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = NovaTextPrimary
                            )
                            Text(
                                text = "Luanda, Angola",
                                fontSize = 11.sp,
                                color = NovaTextSecondary
                            )
                        }
                    }
                },
                actions = {
                    // Alternador de Modo (Passageiro / Motorista)
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = NovaBackground,
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (appMode == AppMode.PASSENGER) NovaOrangePrimary else Color.Transparent,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { appMode = AppMode.PASSENGER }
                                    .testTag("mode_toggle_passenger")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Modo Passageiro",
                                        tint = if (appMode == AppMode.PASSENGER) Color.White else NovaTextSecondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Passageiro",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (appMode == AppMode.PASSENGER) Color.White else NovaTextSecondary
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (appMode == AppMode.DRIVER) NovaOrangePrimary else Color.Transparent,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { appMode = AppMode.DRIVER }
                                    .testTag("mode_toggle_driver")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DirectionsCar,
                                        contentDescription = "Modo Motorista",
                                        tint = if (appMode == AppMode.DRIVER) Color.White else NovaTextSecondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Motorista",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (appMode == AppMode.DRIVER) Color.White else NovaTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    // Botão de Chat em Tempo Real com indicador de mensagens não lidas
                    IconButton(
                        onClick = { showChatScreen = true },
                        modifier = Modifier.testTag("btn_open_chat")
                    ) {
                        val unread = if (appMode == AppMode.PASSENGER) unreadForPassenger else unreadForDriver
                        BadgedBox(
                            badge = {
                                if (unread > 0) {
                                    Badge(
                                        containerColor = NovaOrangePrimary,
                                        contentColor = Color.White
                                    ) {
                                        Text("$unread")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Chat,
                                contentDescription = "Chat em Tempo Real",
                                tint = NovaOrangePrimary
                            )
                        }
                    }

                    // Botão para abrir o perfil do utilizador
                    IconButton(
                        onClick = { showProfileScreen = true },
                        modifier = Modifier.testTag("btn_open_profile")
                    ) {
                        if (!profileState.photoUri.isNullOrBlank()) {
                            AsyncImage(
                                model = profileState.photoUri,
                                contentDescription = "Meu Perfil",
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Meu Perfil",
                                tint = NovaOrangePrimary
                            )
                        }
                    }

                    // Botão para abrir o histórico de corridas anteriores
                    IconButton(
                        onClick = { showHistoryModal = true },
                        modifier = Modifier.testTag("btn_open_history")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Histórico de Corridas",
                            tint = NovaOrangePrimary
                        )
                    }

                    if (appMode == AppMode.PASSENGER) {
                        // Botão para exibir status do GPS
                        IconButton(
                            onClick = { showGpsCard = !showGpsCard },
                            modifier = Modifier.testTag("btn_toggle_gps_sheet")
                        ) {
                            Icon(
                                imageVector = if (locationState.isTrackingActive) Icons.Default.GpsFixed else Icons.Default.GpsNotFixed,
                                contentDescription = "Estado do GPS",
                                tint = if (locationState.isTrackingActive) NovaSuccess else NovaTextSecondary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            if (appMode == AppMode.PASSENGER) {
                ServiceBottomNavigationBar(
                    selectedService = fareState.selectedServiceType,
                    onSelectService = { service -> fareViewModel.selectServiceType(service) },
                    taxiEstimate = fareState.taxiEstimate,
                    bikeEstimate = fareState.bikeEstimate,
                    deliveryEstimate = fareState.deliveryEstimate
                )
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = appMode,
            label = "app_mode_screen_transition"
        ) { mode ->
            when (mode) {
                AppMode.PASSENGER -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // Mapa nativo MapLibre ocupando o fundo
                        MapLibreNativeView(
                            userLat = locationState.latitude,
                            userLng = locationState.longitude,
                            originLat = fareState.originLat,
                            originLng = fareState.originLng,
                            originTitle = fareState.originTitle,
                            destLat = fareState.destinationLat,
                            destLng = fareState.destinationLng,
                            destTitle = fareState.destinationTitle,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Banner de alerta animado para notificações de aproximação/chegada do motorista
                        DriverArrivalAlertBanner(
                            message = passengerRideState.inAppAlert,
                            onOpenChat = { showChatScreen = true },
                            onDismiss = { passengerRideViewModel.dismissInAppAlert() },
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 8.dp)
                                .zIndex(10f)
                        )

                        // Painel sobreposto deslizável com os controlos de estimativa de tarifa e GPS
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Cartão de GPS (aberto ou recolhido)
                            AnimatedVisibility(
                                visible = showGpsCard,
                                enter = expandVertically() + fadeIn(),
                                exit = shrinkVertically() + fadeOut()
                            ) {
                                LocationStatusCard(
                                    locationState = locationState,
                                    onToggleTracking = { locationViewModel.toggleTracking(context) },
                                    onSelectManualPlace = { place ->
                                        locationViewModel.setManualLocation(place)
                                        fareViewModel.setOrigin(place)
                                    },
                                    places = LuandaLocations.places,
                                    onRequestPermission = {
                                        permissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    },
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )
                            }

                            Spacer(modifier = Modifier.weight(1f).heightIn(min = 80.dp))

                            // Se houver uma corrida ativa solicitada pelo passageiro, mostra o cartão de acompanhamento em tempo real
                            if (passengerRideState.activeRide != null) {
                                ActiveRideTrackerCard(
                                    ride = passengerRideState.activeRide!!,
                                    onOpenChat = { showChatScreen = true },
                                    onTriggerArriving = { passengerRideViewModel.triggerDriverArriving(context) },
                                    onTriggerArrived = { passengerRideViewModel.triggerDriverArrived(context) },
                                    onStartTrip = { passengerRideViewModel.startTripToDestination() },
                                    onCompleteRide = { passengerRideViewModel.completeRide(context) },
                                    onCancelRide = { passengerRideViewModel.cancelRide(context) }
                                )
                            } else {
                                // Cartão Principal de Estimativa de Tarifa (Táxi, Bike, Entrega)
                                FareEstimateCard(
                                    fareState = fareState,
                                    places = LuandaLocations.places,
                                    onSelectServiceType = { service -> fareViewModel.selectServiceType(service) },
                                    onSelectOrigin = { place -> fareViewModel.setOrigin(place) },
                                    onSelectDestination = { place -> fareViewModel.setDestination(place) },
                                    onSwapLocations = { fareViewModel.swapOriginAndDestination() },
                                    onSelectTrafficCondition = { cond -> fareViewModel.setTrafficCondition(cond) },
                                    onUseCurrentLocationForOrigin = useGpsAsOrigin,
                                    onOrderRide = { estimate ->
                                        activeOrderEstimate = estimate
                                    }
                                )
                            }
                        }

                        // Diálogo de confirmação de pedido de corrida
                        activeOrderEstimate?.let { estimate ->
                            AlertDialog(
                                onDismissRequest = { activeOrderEstimate = null },
                                icon = {
                                    Icon(
                                        imageVector = when (estimate.serviceType) {
                                            ServiceType.TAXI -> Icons.Default.DirectionsCar
                                            ServiceType.BIKE -> Icons.Default.TwoWheeler
                                            ServiceType.DELIVERY -> Icons.Default.DeliveryDining
                                        },
                                        contentDescription = null,
                                        tint = NovaOrangePrimary,
                                        modifier = Modifier.size(36.dp)
                                    )
                                },
                                title = {
                                    Text(
                                        text = "Confirmar ${estimate.serviceType.title}?",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                },
                                text = {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(
                                            text = "Trajeto: ${fareState.originTitle} ➔ ${fareState.destinationTitle}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Distância estimada: ${estimate.formattedDistance} (${estimate.formattedDuration})",
                                            fontSize = 12.sp,
                                            color = NovaTextSecondary
                                        )
                                        HorizontalDivider(color = NovaCardBorder, thickness = 0.5.dp)
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Total a pagar ao motorista:",
                                                fontSize = 12.sp,
                                                color = NovaTextSecondary
                                            )
                                            Text(
                                                text = estimate.formattedTotalFare,
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = NovaOrangePrimary
                                            )
                                        }
                                    }
                                },
                                confirmButton = {
                                    Button(
                                        onClick = {
                                            val originPlace = fareState.origin ?: LuandaLocations.defaultOrigin
                                            val destPlace = fareState.destination ?: LuandaLocations.defaultDestination
                                            historyViewModel.recordNewRide(
                                                serviceType = estimate.serviceType,
                                                origin = originPlace,
                                                destination = destPlace,
                                                estimate = estimate
                                            )
                                            RideChatRepository.resetForNewRide(
                                                passengerName = profileState.name,
                                                driverName = "Bernardo Kiala"
                                            )
                                            passengerRideViewModel.startRide(
                                                context = context,
                                                originAddress = originPlace.name,
                                                destAddress = destPlace.name,
                                                serviceType = estimate.serviceType,
                                                totalFareAoa = estimate.totalFareAoa
                                            )
                                            activeOrderEstimate = null
                                            Toast.makeText(
                                                context,
                                                "Corrida solicitada! O motorista Bernardo Kiala está a caminho.",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = NovaOrangePrimary)
                                    ) {
                                        Text("Confirmar Pedido")
                                    }
                                },
                                dismissButton = {
                                    TextButton(onClick = { activeOrderEstimate = null }) {
                                        Text("Voltar")
                                    }
                                }
                            )
                        }

                        // Botão Flutuante de Emergência SOS
                        FloatingSosButton(
                            onClick = { showSosDialog = true },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 16.dp, end = 16.dp)
                        )
                    }
                }
                AppMode.DRIVER -> {
                    // Painel de disponibilidade do motorista para receber chamadas
                    DriverDashboardView(
                        driverState = driverState,
                        onToggleOnline = { driverViewModel.toggleOnline() },
                        onAcceptRequest = { driverViewModel.acceptIncomingRequest() },
                        onDeclineRequest = { driverViewModel.declineIncomingRequest() },
                        onCompleteRide = {
                            driverViewModel.completeActiveRide()
                            passengerRideViewModel.completeRide(context)
                        },
                        onToggleService = { service -> driverViewModel.toggleServicePreference(service) },
                        onReturnToPassengerMode = { appMode = AppMode.PASSENGER },
                        onOpenChat = { showChatScreen = true },
                        onNotifyArriving = {
                            val active = driverState.activeAcceptedRide
                            if (active != null) {
                                NotificationHelper.showDriverArrivingNotification(
                                    context = context,
                                    driverName = driverState.driverName,
                                    vehicleInfo = "${driverState.vehicleModel} (${driverState.vehiclePlate})",
                                    etaMinutes = 2,
                                    pickupAddress = active.pickupAddress,
                                    rideId = active.id
                                )
                                passengerRideViewModel.triggerDriverArriving(context)
                                Toast.makeText(context, "Notificação de aproximação enviada!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onNotifyArrived = {
                            val active = driverState.activeAcceptedRide
                            if (active != null) {
                                NotificationHelper.showDriverArrivedNotification(
                                    context = context,
                                    driverName = driverState.driverName,
                                    vehicleInfo = "${driverState.vehicleModel} (${driverState.vehiclePlate})",
                                    pickupAddress = active.pickupAddress,
                                    rideId = active.id
                                )
                                passengerRideViewModel.triggerDriverArrived(context)
                                Toast.makeText(context, "Notificação de chegada ao ponto enviada!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        unreadCount = unreadForDriver,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }

        // Modal do Histórico de Corridas
        if (showHistoryModal) {
            RideHistoryModal(
                historyState = historyState,
                onSelectFilter = { type -> historyViewModel.setServiceFilter(type) },
                onSelectRide = { ride -> historyViewModel.selectRideForDetails(ride) },
                onDismissDetails = { historyViewModel.selectRideForDetails(null) },
                onRepeatRide = { ride ->
                    fareViewModel.setRoute(ride.origin, ride.destination)
                    fareViewModel.selectServiceType(ride.serviceType)
                    Toast.makeText(
                        context,
                        "Trajeto repetido: ${ride.origin.name} ➔ ${ride.destination.name}",
                        Toast.LENGTH_SHORT
                    ).show()
                },
                onClose = { showHistoryModal = false }
            )
        }

        // Diálogo de Emergência SOS com partilha de GPS via SMS
        if (showSosDialog) {
            SosEmergencyDialog(
                locationState = locationState,
                emergencyContact = emergencyContact,
                onUpdateEmergencyContact = { emergencyContact = it },
                onSendSms = { phoneNumber, message ->
                    EmergencyHelper.sendSosSms(context, phoneNumber, message)
                },
                onDialEmergency = { phoneNumber ->
                    EmergencyHelper.dialEmergency(context, phoneNumber)
                },
                onDismiss = { showSosDialog = false }
            )
        }
    }
}
}
