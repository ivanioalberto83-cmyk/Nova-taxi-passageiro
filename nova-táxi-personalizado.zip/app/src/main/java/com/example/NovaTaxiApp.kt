package com.example

import android.app.Application
import com.example.util.MapLibreConfig

/**
 * Classe Application personalizada da NOVA Táxi.
 * Inicializa bibliotecas nativas como MapLibre logo no arranque do processo Android.
 */
class NovaTaxiApp : Application() {

    override fun onCreate() {
        super.onCreate()
        MapLibreConfig.initialize(this)
        com.example.util.NotificationHelper.createNotificationChannels(this)
    }
}
