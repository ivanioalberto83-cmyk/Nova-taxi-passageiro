package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChatMessage
import com.example.model.MessageSenderRole
import com.example.ui.theme.*
import com.example.viewmodel.RideChatViewModel

/**
 * Tela de Chat em Tempo Real entre o Motorista e o Passageiro durante a corrida.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RideChatScreen(
    currentRole: MessageSenderRole,
    currentUserName: String,
    otherPartyName: String,
    otherPartySubtitle: String,
    chatViewModel: RideChatViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val messages by chatViewModel.messages.collectAsState()
    val inputText by chatViewModel.inputText.collectAsState()
    val listState = rememberLazyListState()

    val quickSuggestions = if (currentRole == MessageSenderRole.PASSENGER) {
        chatViewModel.quickPassengerSuggestions
    } else {
        chatViewModel.quickDriverSuggestions
    }

    // Marca mensagens como lidas ao abrir o chat
    LaunchedEffect(messages.size) {
        chatViewModel.markAsRead(currentRole)
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Suporte ao botão voltar nativo do Android
    BackHandler {
        onNavigateBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = NovaOrangePrimary.copy(alpha = 0.15f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (currentRole == MessageSenderRole.PASSENGER) Icons.Default.DirectionsCar else Icons.Default.Person,
                                    contentDescription = null,
                                    tint = NovaOrangePrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = otherPartyName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = NovaTextPrimary
                                )
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(NovaSuccess)
                                )
                            }
                            Text(
                                text = otherPartySubtitle,
                                fontSize = 11.sp,
                                color = NovaTextSecondary
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("btn_chat_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Voltar",
                            tint = NovaTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NovaSurface)
            )
        },
        containerColor = NovaBackground,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Lista de Mensagens
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    ChatMessageItem(
                        message = msg,
                        isFromCurrentUser = msg.senderRole == currentRole
                    )
                }
            }

            // Barra de Sugestões Rápidas (Chips com 1 toque)
            Surface(
                color = NovaSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Respostas rápidas:",
                        fontSize = 11.sp,
                        color = NovaTextSecondary,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(quickSuggestions) { suggestion ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = NovaBackground,
                                border = CardDefaults.outlinedCardBorder().copy(
                                    brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder)
                                ),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable {
                                        chatViewModel.sendQuickSuggestion(
                                            role = currentRole,
                                            senderName = currentUserName,
                                            suggestion = suggestion
                                        )
                                    }
                            ) {
                                Text(
                                    text = suggestion,
                                    fontSize = 12.sp,
                                    color = NovaOrangePrimary,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Barra de Entrada de Mensagens (Input + Botão Enviar)
            Surface(
                color = NovaSurface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { chatViewModel.onInputTextChanged(it) },
                        placeholder = { Text("Mensagem em tempo real...", fontSize = 13.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NovaOrangePrimary,
                            unfocusedBorderColor = NovaCardBorder,
                            focusedContainerColor = NovaBackground,
                            unfocusedContainerColor = NovaBackground
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_text")
                    )

                    IconButton(
                        onClick = {
                            chatViewModel.sendMessage(
                                role = currentRole,
                                senderName = currentUserName
                            )
                        },
                        enabled = inputText.isNotBlank(),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = NovaOrangePrimary,
                            contentColor = Color.White,
                            disabledContainerColor = NovaOrangePrimary.copy(alpha = 0.4f),
                            disabledContentColor = Color.White.copy(alpha = 0.7f)
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("btn_chat_send")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Enviar Mensagem",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Item individual de bolha de mensagem do chat.
 */
@Composable
fun ChatMessageItem(
    message: ChatMessage,
    isFromCurrentUser: Boolean,
    modifier: Modifier = Modifier
) {
    if (message.senderRole == MessageSenderRole.SYSTEM) {
        Box(
            modifier = modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = NovaOrangeLight.copy(alpha = 0.7f),
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = NovaOrangeDark,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = message.text,
                        fontSize = 11.sp,
                        color = NovaOrangeDark,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    } else {
        Column(
            modifier = modifier.fillMaxWidth(),
            horizontalAlignment = if (isFromCurrentUser) Alignment.End else Alignment.Start
        ) {
            Surface(
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isFromCurrentUser) 16.dp else 4.dp,
                    bottomEnd = if (isFromCurrentUser) 4.dp else 16.dp
                ),
                color = if (isFromCurrentUser) NovaOrangePrimary else NovaSurface,
                border = if (isFromCurrentUser) null else CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder)
                ),
                shadowElevation = if (isFromCurrentUser) 2.dp else 1.dp,
                modifier = Modifier.widthIn(max = 280.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (!isFromCurrentUser) {
                        Text(
                            text = message.senderName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NovaOrangePrimary
                        )
                    }

                    Text(
                        text = message.text,
                        fontSize = 13.sp,
                        color = if (isFromCurrentUser) Color.White else NovaTextPrimary,
                        lineHeight = 18.sp
                    )

                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = message.formattedTime,
                            fontSize = 10.sp,
                            color = if (isFromCurrentUser) Color.White.copy(alpha = 0.8f) else NovaTextSecondary
                        )
                        if (isFromCurrentUser) {
                            Icon(
                                imageVector = Icons.Default.DoneAll,
                                contentDescription = "Entregue",
                                tint = Color.White.copy(alpha = 0.85f),
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
