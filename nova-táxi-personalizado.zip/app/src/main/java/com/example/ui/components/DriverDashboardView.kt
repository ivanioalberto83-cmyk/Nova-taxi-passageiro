package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsBike
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DriverRideRequest
import com.example.model.ServiceType
import com.example.ui.theme.*
import com.example.viewmodel.DriverUiState

/**
 * Painel de Disponibilidade do Motorista da NOVA Táxi.
 * Substitui o mapa de passageiro e oferece controlo de chamadas, ganhos e preferências.
 */
@Composable
fun DriverDashboardView(
    driverState: DriverUiState,
    onToggleOnline: () -> Unit,
    onAcceptRequest: () -> Unit,
    onDeclineRequest: () -> Unit,
    onCompleteRide: () -> Unit,
    onToggleService: (ServiceType) -> Unit,
    onReturnToPassengerMode: () -> Unit,
    onOpenChat: () -> Unit = {},
    onNotifyArriving: () -> Unit = {},
    onNotifyArrived: () -> Unit = {},
    unreadCount: Int = 0,
    modifier: Modifier = Modifier
) {
    // Permite voltar ao modo de passageiro usando o botão físico/gestual de voltar
    BackHandler {
        onReturnToPassengerMode()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NovaBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Cabeçalho do Motorista
        Card(
            modifier = Modifier.fillMaxWidth().testTag("driver_profile_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = NovaOrangeLight,
                    modifier = Modifier.size(50.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = NovaOrangePrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = driverState.driverName,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = NovaTextPrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = NovaOrangeLight
                        ) {
                            Text(
                                text = "★ ${driverState.rating}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = NovaOrangeDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "${driverState.vehicleModel} • ${driverState.vehiclePlate}",
                        fontSize = 12.sp,
                        color = NovaTextSecondary
                    )
                }

                // Botão para alternar de volta para o Modo Passageiro
                OutlinedButton(
                    onClick = onReturnToPassengerMode,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("btn_switch_to_passenger")
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsCar,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = NovaOrangePrimary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Passageiro", fontSize = 11.sp, color = NovaTextPrimary)
                }
            }
        }

        // Cartão Principal: Alternador de Disponibilidade (Online / Offline)
        AvailabilityControlCard(
            isOnline = driverState.isOnline,
            onToggle = onToggleOnline
        )

        // Chamada de Corrida Recebida (Alerta Dinâmico)
        driverState.incomingRequest?.let { request ->
            IncomingRideRequestCard(
                request = request,
                onAccept = onAcceptRequest,
                onDecline = onDeclineRequest
            )
        }

        // Corrida em Curso Aceita
        driverState.activeAcceptedRide?.let { activeRide ->
            ActiveRideCard(
                ride = activeRide,
                unreadCount = unreadCount,
                onOpenChat = onOpenChat,
                onNotifyArriving = onNotifyArriving,
                onNotifyArrived = onNotifyArrived,
                onComplete = onCompleteRide
            )
        }

        // Resumo de Desempenho e Ganhos do Dia
        Text(
            text = "Estatísticas de Hoje em Luanda",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = NovaTextSecondary
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = "Ganhos de Hoje",
                value = "${driverState.todayEarningsAoa.toInt()} Kz",
                icon = Icons.Default.Payments,
                iconColor = NovaSuccess,
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "Corridas",
                value = "${driverState.completedTripsToday} viagens",
                icon = Icons.Default.Route,
                iconColor = NovaOrangePrimary,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = "Tempo Conectado",
                value = driverState.onlineTimeFormatted,
                icon = Icons.Default.Schedule,
                iconColor = Color(0xFF3B82F6),
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "Taxa de Aceitação",
                value = "${driverState.acceptanceRatePercent}%",
                icon = Icons.Default.CheckCircle,
                iconColor = NovaSuccess,
                modifier = Modifier.weight(1f)
            )
        }

        // Preferências de Serviços Aceitos (Táxi, Bike, Entrega)
        Card(
            modifier = Modifier.fillMaxWidth().testTag("service_preferences_card"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Modalidades Ativas para Receber Chamadas",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = NovaTextPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ServiceType.entries.forEach { type ->
                        val isEnabled = driverState.acceptedServices.contains(type)
                        FilterChip(
                            selected = isEnabled,
                            onClick = { onToggleService(type) },
                            leadingIcon = {
                                Icon(
                                    imageVector = when (type) {
                                        ServiceType.TAXI -> Icons.Default.DirectionsCar
                                        ServiceType.BIKE -> Icons.AutoMirrored.Filled.DirectionsBike
                                        ServiceType.DELIVERY -> Icons.Default.DeliveryDining
                                    },
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = { Text(type.title, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NovaOrangeLight,
                                selectedLabelColor = NovaOrangeDark
                            ),
                            modifier = Modifier.testTag("driver_pref_${type.name.lowercase()}")
                        )
                    }
                }
            }
        }
    }
}

/**
 * Cartão de Controlo de Disponibilidade (Online / Offline).
 */
@Composable
private fun AvailabilityControlCard(
    isOnline: Boolean,
    onToggle: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("driver_availability_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isOnline) NovaSuccessContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (isOnline) NovaSuccess else NovaCardBorder
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Indicador de Sinal e Radar
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(72.dp)
            ) {
                if (isOnline) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(NovaSuccess.copy(alpha = 0.2f))
                    )
                }

                Surface(
                    shape = CircleShape,
                    color = if (isOnline) NovaSuccess else NovaTextSecondary.copy(alpha = 0.2f),
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isOnline) Icons.Default.CellTower else Icons.Default.PowerSettingsNew,
                            contentDescription = null,
                            tint = if (isOnline) Color.White else NovaTextSecondary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (isOnline) "DISPONÍVEL PARA CORRIDAS" else "VOCÊ ESTÁ OFFLINE",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    color = if (isOnline) NovaSuccess else NovaTextPrimary
                )
                Text(
                    text = if (isOnline)
                        "A monitorizar chamadas de passageiros na sua área em Luanda."
                    else
                        "Ligue o radar para começar a receber pedidos de táxi, bike ou entrega.",
                    fontSize = 11.sp,
                    color = NovaTextSecondary,
                    textAlign = TextAlign.Center
                )
            }

            // Botão Principal Ligar / Desligar
            Button(
                onClick = onToggle,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isOnline) Color(0xFFDC2626) else NovaSuccess
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_toggle_driver_online")
            ) {
                Icon(
                    imageVector = if (isOnline) Icons.Default.Close else Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isOnline) "Ficar Offline" else "Ficar Online Agora",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Cartão de chamada de passageiro recebida em tempo real.
 */
@Composable
private fun IncomingRideRequestCard(
    request: DriverRideRequest,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("incoming_ride_request_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = NovaOrangeLight),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(NovaOrangePrimary)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = NovaOrangePrimary,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(
                        text = "NOVA CHAMADA (${request.serviceType.title})",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = NovaOrangeDark
                    )
                }

                Text(
                    text = request.formattedEarnings,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = NovaTextPrimary
                )
            }

            HorizontalDivider(color = NovaOrangePrimary.copy(alpha = 0.3f), thickness = 0.5.dp)

            Text(
                text = "Passageiro: ${request.passengerName} (★ ${request.passengerRating})",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = NovaTextPrimary
            )

            // Trajeto
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "🟢 Recolha: ${request.pickupAddress} (${request.distanceToPickupKm} km • ${request.etaPickupMinutes} min)",
                    fontSize = 12.sp,
                    color = NovaTextPrimary
                )
                Text(
                    text = "🏁 Destino: ${request.dropoffAddress} (${request.tripDistanceKm} km)",
                    fontSize = 12.sp,
                    color = NovaTextSecondary
                )
            }

            // Botões Aceitar / Recusar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onDecline,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).testTag("btn_decline_ride")
                ) {
                    Text("Recusar", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onAccept,
                    colors = ButtonDefaults.buttonColors(containerColor = NovaSuccess),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1.5f).testTag("btn_accept_ride")
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Aceitar Corrida", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Cartão de corrida em curso após aceitação pelo motorista.
 */
@Composable
private fun ActiveRideCard(
    ride: DriverRideRequest,
    unreadCount: Int,
    onOpenChat: () -> Unit,
    onNotifyArriving: () -> Unit = {},
    onNotifyArrived: () -> Unit = {},
    onComplete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("active_ride_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(NovaSuccess)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CORRIDA EM ANDAMENTO",
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    color = NovaSuccess
                )
                Text(
                    text = ride.formattedEarnings,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = NovaTextPrimary
                )
            }

            Text(
                text = "A transportar ${ride.passengerName} para ${ride.dropoffAddress}",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = NovaTextPrimary
            )

            Text(
                text = "Recolha: ${ride.pickupAddress}",
                fontSize = 12.sp,
                color = NovaTextSecondary
            )

            // Botões de Alerta de Chegada ao Passageiro
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = NovaBackground,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Alertar Passageiro no Local de Partida:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NovaTextSecondary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilledTonalButton(
                            onClick = onNotifyArriving,
                            modifier = Modifier.weight(1f).testTag("btn_driver_notify_arriving"),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.NearMe,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("A Chegar (2 min)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        FilledTonalButton(
                            onClick = onNotifyArrived,
                            modifier = Modifier.weight(1f).testTag("btn_driver_notify_arrived"),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Cheguei ao Local", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenChat,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NovaOrangePrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("btn_driver_open_chat")
                ) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (unreadCount > 0) "Chat ($unreadCount)" else "Chat",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = onComplete,
                    colors = ButtonDefaults.buttonColors(containerColor = NovaOrangePrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1.5f)
                        .height(44.dp)
                        .testTag("btn_complete_ride")
                ) {
                    Icon(
                        imageVector = Icons.Default.DoneAll,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Concluir Viagem", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = NovaTextSecondary
                )
            }

            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = NovaTextPrimary
            )
        }
    }
}
