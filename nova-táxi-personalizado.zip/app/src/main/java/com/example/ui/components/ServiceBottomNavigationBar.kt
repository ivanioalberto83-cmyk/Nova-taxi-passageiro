package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsBike
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FareEstimate
import com.example.model.ServiceType
import com.example.ui.theme.*

/**
 * Menu inferior de seleção de modalidade de serviço (Táxi, Bike, Entrega)
 * utilizando botões estilizados com ícones do Material Icons Extended.
 */
@Composable
fun ServiceBottomNavigationBar(
    selectedService: ServiceType,
    onSelectService: (ServiceType) -> Unit,
    taxiEstimate: FareEstimate?,
    bikeEstimate: FareEstimate?,
    deliveryEstimate: FareEstimate?,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("service_bottom_navigation_bar"),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        shadowElevation = 12.dp,
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder.copy(alpha = 0.8f))
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Título discreto do menu inferior
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SERVIÇOS NOVA",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = NovaTextSecondary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Toque para alternar modo",
                    fontSize = 10.sp,
                    color = NovaTextSecondary
                )
            }

            // Barra de Botões com Ícones do Material Icons Extended
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. Botão Táxi
                ServiceNavButton(
                    serviceType = ServiceType.TAXI,
                    isSelected = selectedService == ServiceType.TAXI,
                    icon = Icons.Filled.LocalTaxi,
                    label = "Táxi",
                    subLabel = taxiEstimate?.formattedTotalFare ?: "4 lugares",
                    testTag = "btn_service_taxi",
                    onSelect = { onSelectService(ServiceType.TAXI) },
                    modifier = Modifier.weight(1f)
                )

                // 2. Botão Bike
                ServiceNavButton(
                    serviceType = ServiceType.BIKE,
                    isSelected = selectedService == ServiceType.BIKE,
                    icon = Icons.AutoMirrored.Filled.DirectionsBike,
                    label = "Bike",
                    subLabel = bikeEstimate?.formattedTotalFare ?: "Rápido",
                    testTag = "btn_service_bike",
                    onSelect = { onSelectService(ServiceType.BIKE) },
                    modifier = Modifier.weight(1f)
                )

                // 3. Botão Entrega
                ServiceNavButton(
                    serviceType = ServiceType.DELIVERY,
                    isSelected = selectedService == ServiceType.DELIVERY,
                    icon = Icons.Filled.DeliveryDining,
                    label = "Entrega",
                    subLabel = deliveryEstimate?.formattedTotalFare ?: "Encomendas",
                    testTag = "btn_service_delivery",
                    onSelect = { onSelectService(ServiceType.DELIVERY) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/**
 * Botão individual do menu de serviços com animação de seleção, ícone e valor estimado.
 */
@Composable
private fun ServiceNavButton(
    serviceType: ServiceType,
    isSelected: Boolean,
    icon: ImageVector,
    label: String,
    subLabel: String,
    testTag: String,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }

    val containerColor by animateColorAsState(
        targetValue = if (isSelected) NovaOrangeLight else Color.Transparent,
        label = "containerColor"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isSelected) NovaOrangePrimary else NovaCardBorder.copy(alpha = 0.6f),
        label = "borderColor"
    )

    val contentColor by animateColorAsState(
        targetValue = if (isSelected) NovaOrangePrimary else NovaTextSecondary,
        label = "contentColor"
    )

    val scale by animateFloatAsState(
        targetValue = if (isSelected) 1.02f else 1.0f,
        label = "buttonScale"
    )

    Surface(
        modifier = modifier
            .scale(scale)
            .heightIn(min = 64.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(bounded = true, color = NovaOrangePrimary),
                onClick = onSelect
            )
            .testTag(testTag),
        color = containerColor,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Container do Ícone com indicador de seleção
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) NovaOrangePrimary else NovaBackground
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isSelected) Color.White else NovaTextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Rótulo Principal (Táxi, Bike, Entrega)
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                color = if (isSelected) NovaTextPrimary else NovaTextSecondary,
                textAlign = TextAlign.Center
            )

            // Subtítulo ou Valor Estimado da Tarifa
            Text(
                text = subLabel,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) NovaOrangeDark else NovaTextSecondary,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}
