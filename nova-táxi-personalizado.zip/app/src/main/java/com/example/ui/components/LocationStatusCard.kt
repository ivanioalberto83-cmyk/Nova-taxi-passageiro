package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LuandaPlace
import com.example.ui.theme.*
import com.example.viewmodel.LocationUiState

@Composable
fun LocationStatusCard(
    locationState: LocationUiState,
    onToggleTracking: () -> Unit,
    onSelectManualPlace: (LuandaPlace) -> Unit,
    places: List<LuandaPlace>,
    onRequestPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showPlaceSelector by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("location_status_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Cabeçalho com Status de GPS e Ação de Ativar/Desativar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                if (locationState.isTrackingActive) NovaSuccessContainer else NovaOrangeLight
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (locationState.isTrackingActive) Icons.Default.GpsFixed else Icons.Default.GpsNotFixed,
                            contentDescription = "GPS Status",
                            tint = if (locationState.isTrackingActive) NovaSuccess else NovaOrangePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "Posição do Passageiro (GPS)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = NovaTextPrimary
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (locationState.isTrackingActive) NovaSuccess else NovaTextSecondary
                                    )
                            )
                            Text(
                                text = if (locationState.isTrackingActive) "TEMPO REAL ATIVO" else "RASTREAMENTO PAUSADO",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (locationState.isTrackingActive) NovaSuccess else NovaTextSecondary
                            )
                        }
                    }
                }

                // Botão Ligar/Desligar Rastreamento
                IconButton(
                    onClick = {
                        if (!locationState.hasPermission) {
                            onRequestPermission()
                        } else {
                            onToggleTracking()
                        }
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(NovaBackground)
                        .testTag("btn_toggle_tracking")
                ) {
                    Icon(
                        imageVector = if (locationState.isTrackingActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Alternar Rastreamento",
                        tint = NovaOrangePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Exibição de Coordenadas e Ponto de Luanda mais Próximo
            if (locationState.latitude != null && locationState.longitude != null) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NovaBackground,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "COORDENADAS ATUAIS",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NovaTextSecondary
                                )
                                Text(
                                    text = String.format("%.5f, %.5f", locationState.latitude, locationState.longitude),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = NovaTextPrimary
                                )
                            }

                            locationState.accuracyMeters?.let { acc ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (acc <= 10f) NovaSuccessContainer else NovaOrangeLight
                                ) {
                                    Text(
                                        text = "± ${acc.toInt()}m",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (acc <= 10f) NovaSuccess else NovaOrangeDark,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // Ponto de Referência Próximo em Luanda
                        locationState.nearestPlace?.let { place ->
                            HorizontalDivider(color = NovaCardBorder, thickness = 0.5.dp)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NearMe,
                                    contentDescription = "Mais Próximo",
                                    tint = NovaOrangePrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Column {
                                    Text(
                                        text = "Zona mais próxima em Luanda:",
                                        fontSize = 10.sp,
                                        color = NovaTextSecondary
                                    )
                                    Text(
                                        text = "${place.name} (${locationState.distanceToNearestKm ?: 0.0} km)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NovaTextPrimary
                                    )
                                }
                            }
                        }

                        // Telemetria Adicional: Velocidade e Atualização
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Velocidade: ${String.format("%.1f", locationState.speedKmh ?: 0f)} km/h",
                                fontSize = 11.sp,
                                color = NovaTextSecondary
                            )
                            Text(
                                text = "Atualizado: ${locationState.lastUpdatedFormatted}",
                                fontSize = 11.sp,
                                color = NovaTextSecondary
                            )
                        }
                    }
                }
            } else {
                // Estado sem coordenadas ativas
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NovaOrangeLight.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationSearching,
                            contentDescription = "A procurar sinal",
                            tint = NovaOrangePrimary
                        )
                        Text(
                            text = if (!locationState.hasPermission)
                                "Autorize a localização para detetar o seu ponto de recolha automaticamente."
                            else
                                "A estabelecer contacto com satélites GPS...",
                            fontSize = 12.sp,
                            color = NovaOrangeDark,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Ações: Autorizar Permissão ou Selecionar Local Manualmente
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!locationState.hasPermission) {
                    Button(
                        onClick = onRequestPermission,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_request_location_perm"),
                        colors = ButtonDefaults.buttonColors(containerColor = NovaOrangePrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ativar GPS", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedButton(
                    onClick = { showPlaceSelector = true },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_select_manual_location"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Place,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = NovaOrangePrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Escolher na Lista", fontSize = 12.sp, color = NovaTextPrimary)
                }
            }
        }
    }

    // Diálogo de Seleção de Local Manual em Luanda
    if (showPlaceSelector) {
        AlertDialog(
            onDismissRequest = { showPlaceSelector = false },
            title = {
                Text("Locais de Luanda", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    places.forEach { place ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectManualPlace(place)
                                    showPlaceSelector = false
                                }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationCity,
                                contentDescription = null,
                                tint = NovaOrangePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(place.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(place.district, fontSize = 11.sp, color = NovaTextSecondary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPlaceSelector = false }) {
                    Text("Fechar")
                }
            }
        )
    }
}
