package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NovaOrangePrimary = Color(0xFFFF6B00)
val NovaOrangeDark = Color(0xFFE65100)
val NovaOrangeLight = Color(0xFFFFF3E0)
val NovaBlack = Color(0xFF121212)
val NovaSurface = Color(0xFFFFFFFF)
val NovaBackground = Color(0xFFF8F9FA)
val NovaTextPrimary = Color(0xFF1E293B)
val NovaTextSecondary = Color(0xFF64748B)
val NovaCardBorder = Color(0xFFE2E8F0)
val NovaSuccess = Color(0xFF10B981)
val NovaSuccessContainer = Color(0xFFD1FAE5)
val NovaError = Color(0xFFEF4444)
