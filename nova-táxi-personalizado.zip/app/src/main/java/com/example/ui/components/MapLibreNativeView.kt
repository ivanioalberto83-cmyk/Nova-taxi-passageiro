package com.example.ui.components

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.NovaOrangePrimary
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.util.MapLibreConfig
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style

/**
 * Componente de mapa vetorial nativo MapLibre.
 * Suporta visualização da localização do passageiro ou rota Origem -> Destino com marcadores.
 * Utiliza o estilo OpenFreeMap sem requerer chave de API paga.
 */
@Composable
fun MapLibreNativeView(
    userLat: Double? = null,
    userLng: Double? = null,
    originLat: Double? = null,
    originLng: Double? = null,
    originTitle: String = "Ponto de Partida",
    destLat: Double? = null,
    destLng: Double? = null,
    destTitle: String = "Destino",
    styleUrl: String = MapLibreConfig.DEFAULT_STYLE,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var mapLibreMap by remember { mutableStateOf<MapLibreMap?>(null) }
    var userMarker by remember { mutableStateOf<Marker?>(null) }
    var originMarker by remember { mutableStateOf<Marker?>(null) }
    var destMarker by remember { mutableStateOf<Marker?>(null) }

    val mapView = remember(context) {
        try {
            // Inicializa o MapLibre ANTES de qualquer criação de MapView
            MapLibreConfig.initialize(context)
            MapView(context).apply {
                getMapAsync { map ->
                    mapLibreMap = map
                    map.setStyle(Style.Builder().fromUri(styleUrl)) {
                        val initialCenter = when {
                            originLat != null && originLng != null -> LatLng(originLat, originLng)
                            userLat != null && userLng != null -> LatLng(userLat, userLng)
                            else -> MapLibreConfig.LUANDA_CENTER
                        }

                        map.cameraPosition = CameraPosition.Builder()
                            .target(initialCenter)
                            .zoom(13.0)
                            .build()
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e("MapLibreNativeView", "Falha ao instanciar MapView: ${e.message}", e)
            null
        }
    }

    // Atualiza marcadores de Origem e Destino
    LaunchedEffect(originLat, originLng, destLat, destLng, mapLibreMap) {
        val map = mapLibreMap ?: return@LaunchedEffect

        originMarker?.remove()
        destMarker?.remove()

        if (originLat != null && originLng != null) {
            originMarker = map.addMarker(
                MarkerOptions()
                    .position(LatLng(originLat, originLng))
                    .title("🟢 Origem: $originTitle")
                    .snippet("Ponto de partida da corrida")
            )
        }

        if (destLat != null && destLng != null) {
            destMarker = map.addMarker(
                MarkerOptions()
                    .position(LatLng(destLat, destLng))
                    .title("🏁 Destino: $destTitle")
                    .snippet("Ponto de chegada")
            )
        }

        // Se ambos estiverem definidos, enquadra a câmara para mostrar os dois pontos
        if (originLat != null && originLng != null && destLat != null && destLng != null) {
            try {
                val bounds = LatLngBounds.Builder()
                    .include(LatLng(originLat, originLng))
                    .include(LatLng(destLat, destLng))
                    .build()
                map.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 120))
            } catch (e: Exception) {
                // Bounds com mesma coordenada ou fora de vista
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(originLat, originLng), 13.0))
            }
        } else if (originLat != null && originLng != null) {
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(originLat, originLng), 14.0))
        }
    }

    // Atualiza marcador de posição GPS do utilizador
    LaunchedEffect(userLat, userLng, mapLibreMap) {
        val map = mapLibreMap ?: return@LaunchedEffect
        if (userLat != null && userLng != null) {
            userMarker?.remove()
            val userPos = LatLng(userLat, userLng)
            userMarker = map.addMarker(
                MarkerOptions()
                    .position(userPos)
                    .title("Passageiro NOVA Táxi")
                    .snippet("Posição GPS em tempo real")
            )
            if (originLat == null && destLat == null) {
                map.animateCamera(CameraUpdateFactory.newLatLng(userPos))
            }
        }
    }

    // Gestão do ciclo de vida exigido pelo MapLibre
    DisposableEffect(lifecycleOwner, mapView) {
        val view = mapView ?: return@DisposableEffect onDispose {}
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> view.onStart()
                Lifecycle.Event.ON_RESUME -> view.onResume()
                Lifecycle.Event.ON_PAUSE -> view.onPause()
                Lifecycle.Event.ON_STOP -> view.onStop()
                Lifecycle.Event.ON_DESTROY -> view.onDestroy()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Box(modifier = modifier) {
        if (mapView != null) {
            AndroidView(
                factory = { mapView },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Visualização de fallback elegante caso a renderização nativa esteja indisponível
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF1F5F9)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Navigation,
                        contentDescription = "Mapa de Navegação",
                        tint = NovaOrangePrimary,
                        modifier = Modifier.size(44.dp)
                    )
                    Text(
                        text = "NOVA Táxi - Rede de Navegação de Luanda",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = NovaTextPrimary
                    )
                    Text(
                        text = "Ingombota • Maianga • Talatona • Viana • Kilamba",
                        fontSize = 11.sp,
                        color = NovaTextSecondary
                    )
                }
            }
        }
    }
}
