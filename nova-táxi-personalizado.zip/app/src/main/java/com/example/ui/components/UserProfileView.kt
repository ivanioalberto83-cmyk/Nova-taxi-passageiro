package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.UserProfile
import com.example.ui.theme.*

/**
 * Tela de Perfil do Utilizador da NOVA Táxi.
 * Permite editar nome, telefone, email e adicionar foto através do seletor de imagens do sistema (Photo Picker).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    userProfile: UserProfile,
    onSaveProfile: (name: String, phone: String, email: String) -> Boolean,
    onUpdatePhoto: (uriString: String?) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var nameInput by remember(userProfile.name) { mutableStateOf(userProfile.name) }
    var phoneInput by remember(userProfile.phoneNumber) { mutableStateOf(userProfile.phoneNumber) }
    var emailInput by remember(userProfile.email) { mutableStateOf(userProfile.email) }
    var hasUnsavedChanges by remember { mutableStateOf(false) }

    // Android Zero-Permission Photo Picker (compatível com Google Play Policy)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onUpdatePhoto(uri.toString())
            Toast.makeText(context, "Foto de perfil atualizada!", Toast.LENGTH_SHORT).show()
        }
    }

    // Suporte ao botão/gesto voltar do Android
    BackHandler {
        onNavigateBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Meu Perfil",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = NovaTextPrimary
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("btn_profile_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Voltar",
                            tint = NovaTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NovaSurface
                )
            )
        },
        containerColor = NovaBackground,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {

            // ===== SEÇÃO DO AVATAR & FOTO DE PERFIL =====
            Box(
                contentAlignment = Alignment.BottomEnd,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = NovaOrangePrimary.copy(alpha = 0.15f),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(NovaOrangePrimary)
                    ),
                    modifier = Modifier
                        .size(124.dp)
                        .shadow(6.dp, CircleShape)
                        .clickable {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                        .testTag("avatar_profile_click")
                ) {
                    if (!userProfile.photoUri.isNullOrBlank()) {
                        AsyncImage(
                            model = userProfile.photoUri,
                            contentDescription = "Foto do Utilizador",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Text(
                                text = userProfile.name.split(" ")
                                    .take(2)
                                    .mapNotNull { it.firstOrNull()?.uppercase() }
                                    .joinToString(""),
                                fontSize = 38.sp,
                                fontWeight = FontWeight.Black,
                                color = NovaOrangePrimary
                            )
                        }
                    }
                }

                // Botão flutuante de câmera no canto do avatar
                Surface(
                    shape = CircleShape,
                    color = NovaOrangePrimary,
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .clickable {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                        .testTag("btn_change_photo_badge")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Alterar Foto",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Ações da foto de perfil
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = NovaOrangePrimary
                    ),
                    modifier = Modifier.testTag("btn_choose_photo")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (userProfile.photoUri == null) "Escolher Foto" else "Trocar Foto",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (!userProfile.photoUri.isNullOrBlank()) {
                    TextButton(
                        onClick = {
                            onUpdatePhoto(null)
                            Toast.makeText(context, "Foto removida", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier.testTag("btn_remove_photo")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Remover",
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // ===== CARTÃO DE RESUMO / STATUS =====
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NovaSurface),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = NovaOrangePrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "%.2f".format(userProfile.rating),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = NovaTextPrimary
                            )
                        }
                        Text(
                            text = "Avaliação",
                            fontSize = 11.sp,
                            color = NovaTextSecondary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .height(30.dp)
                            .width(1.dp)
                            .background(NovaCardBorder)
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${userProfile.totalRidesAsPassenger}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = NovaTextPrimary
                        )
                        Text(
                            text = "Corridas",
                            fontSize = 11.sp,
                            color = NovaTextSecondary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .height(30.dp)
                            .width(1.dp)
                            .background(NovaCardBorder)
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Passageiro",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = NovaOrangePrimary
                        )
                        Text(
                            text = "Status",
                            fontSize = 11.sp,
                            color = NovaTextSecondary
                        )
                    }
                }
            }

            // ===== FORMULÁRIO DE EDIÇÃO DO PERFIL =====
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NovaSurface),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Dados Pessoais",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = NovaTextPrimary
                    )

                    // Campo de Nome Completo
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = {
                            nameInput = it
                            hasUnsavedChanges = true
                        },
                        label = { Text("Nome Completo") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = NovaOrangePrimary
                            )
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NovaOrangePrimary,
                            focusedLabelColor = NovaOrangePrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_name_input")
                    )

                    // Campo de Telefone
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = {
                            phoneInput = it
                            hasUnsavedChanges = true
                        },
                        label = { Text("Telefone (Angola)") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = null,
                                tint = NovaOrangePrimary
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NovaOrangePrimary,
                            focusedLabelColor = NovaOrangePrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_phone_input")
                    )

                    // Campo de Email
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = {
                            emailInput = it
                            hasUnsavedChanges = true
                        },
                        label = { Text("Email de Contacto") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = null,
                                tint = NovaOrangePrimary
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NovaOrangePrimary,
                            focusedLabelColor = NovaOrangePrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_email_input")
                    )

                    // Informação de Método de Pagamento
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NovaBackground,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CreditCard,
                                contentDescription = null,
                                tint = NovaOrangePrimary
                            )
                            Column {
                                Text(
                                    text = "Pagamento Preferencial",
                                    fontSize = 11.sp,
                                    color = NovaTextSecondary
                                )
                                Text(
                                    text = userProfile.preferredPaymentMethod,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = NovaTextPrimary
                                )
                            }
                        }
                    }

                    // Botão Salvar
                    Button(
                        onClick = {
                            val success = onSaveProfile(nameInput, phoneInput, emailInput)
                            if (success) {
                                hasUnsavedChanges = false
                                Toast.makeText(context, "Perfil guardado com sucesso!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Preencha o nome e telefone corretamente.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NovaOrangePrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("profile_save_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Guardar Alterações",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            // Nota informativa sobre segurança
            Text(
                text = "Os teus dados são partilhados apenas com o motorista durante a realização da corrida por questões de segurança.",
                fontSize = 11.sp,
                color = NovaTextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}
