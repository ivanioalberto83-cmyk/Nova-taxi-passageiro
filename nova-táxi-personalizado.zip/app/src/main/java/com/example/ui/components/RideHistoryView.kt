package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsBike
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RideHistoryItem
import com.example.model.RideStatus
import com.example.model.ServiceType
import com.example.ui.theme.*
import com.example.viewmodel.RideHistoryUiState

/**
 * Componente modal de histórico de corridas anteriores da NOVA Táxi em Luanda.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RideHistoryModal(
    historyState: RideHistoryUiState,
    onSelectFilter: (ServiceType?) -> Unit,
    onSelectRide: (RideHistoryItem) -> Unit,
    onDismissDetails: () -> Unit,
    onRepeatRide: (RideHistoryItem) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    ModalBottomSheet(
        onDismissRequest = onClose,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = { BottomSheetDefaults.DragHandle() },
        modifier = modifier.testTag("ride_history_modal")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Cabeçalho com estatísticas de resumo
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Histórico de Corridas",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = NovaTextPrimary
                    )
                    Text(
                        text = "${historyState.totalRidesCount} viagens realizadas em Luanda",
                        fontSize = 12.sp,
                        color = NovaTextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NovaOrangeLight
                ) {
                    Text(
                        text = "Total: ${historyState.formattedTotalSpent}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NovaOrangeDark,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // Filtros rápidos por modalidade (Todos, Táxi, Bike, Entrega)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = historyState.selectedFilter == null,
                    onClick = { onSelectFilter(null) },
                    label = { Text("Todos (${historyState.rides.size})", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NovaOrangeLight,
                        selectedLabelColor = NovaOrangeDark
                    ),
                    modifier = Modifier.testTag("filter_chip_all")
                )

                ServiceType.entries.forEach { type ->
                    val isSelected = historyState.selectedFilter == type
                    val count = historyState.rides.count { it.serviceType == type }
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectFilter(type) },
                        leadingIcon = {
                            Icon(
                                imageVector = when (type) {
                                    ServiceType.TAXI -> Icons.Default.DirectionsCar
                                    ServiceType.BIKE -> Icons.AutoMirrored.Filled.DirectionsBike
                                    ServiceType.DELIVERY -> Icons.Default.DeliveryDining
                                },
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text("${type.title} ($count)", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NovaOrangeLight,
                            selectedLabelColor = NovaOrangeDark
                        ),
                        modifier = Modifier.testTag("filter_chip_${type.name.lowercase()}")
                    )
                }
            }

            HorizontalDivider(color = NovaCardBorder, thickness = 0.5.dp)

            // Lista de trajetos anteriores
            val rides = historyState.filteredRides
            if (rides.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsCar,
                            contentDescription = null,
                            tint = NovaTextSecondary.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "Nenhuma corrida encontrada nesta categoria.",
                            fontSize = 13.sp,
                            color = NovaTextSecondary
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("ride_history_list"),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(rides, key = { it.id }) { ride ->
                        RideHistoryCard(
                            ride = ride,
                            onClick = { onSelectRide(ride) },
                            onRepeatRide = {
                                onRepeatRide(ride)
                                onClose()
                            }
                        )
                    }
                }
            }
        }
    }

    // Modal de Detalhes da Corrida Selecionada
    historyState.selectedRideDetails?.let { detail ->
        RideDetailsDialog(
            ride = detail,
            onDismiss = onDismissDetails,
            onRepeatRide = {
                onRepeatRide(detail)
                onDismissDetails()
                onClose()
            }
        )
    }
}

/**
 * Cartão de apresentação do trajeto realizado no histórico.
 */
@Composable
fun RideHistoryCard(
    ride: RideHistoryItem,
    onClick: () -> Unit,
    onRepeatRide: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("ride_history_item_${ride.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NovaBackground),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Cabeçalho: Ícone do serviço, data e valor
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(NovaOrangeLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (ride.serviceType) {
                                ServiceType.TAXI -> Icons.Default.DirectionsCar
                                ServiceType.BIKE -> Icons.AutoMirrored.Filled.DirectionsBike
                                ServiceType.DELIVERY -> Icons.Default.DeliveryDining
                            },
                            contentDescription = ride.serviceType.title,
                            tint = NovaOrangePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column {
                        Text(
                            text = ride.serviceType.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = NovaTextPrimary
                        )
                        Text(
                            text = ride.dateFormatted,
                            fontSize = 11.sp,
                            color = NovaTextSecondary
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = ride.formattedFare,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = NovaTextPrimary
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (ride.status == RideStatus.COMPLETED) NovaSuccessContainer else NovaError.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = ride.status.label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (ride.status == RideStatus.COMPLETED) NovaSuccess else NovaError,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = NovaCardBorder, thickness = 0.5.dp)

            // Timeline do Trajeto (Origem -> Destino)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Origem
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(NovaSuccess)
                    )
                    Text(
                        text = "${ride.origin.name} (${ride.origin.district})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NovaTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Destino
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(NovaOrangePrimary)
                    )
                    Text(
                        text = "${ride.destination.name} (${ride.destination.district})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NovaTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Rodapé do Card com Telemetria e Botão de Ação "Repetir Viagem"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${ride.formattedDistance} • ${ride.formattedDuration}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NovaTextPrimary
                    )
                    Text(
                        text = "Motorista: ${ride.driverName}",
                        fontSize = 10.sp,
                        color = NovaTextSecondary
                    )
                }

                // Botão "Repetir Viagem" que preenche automaticamente a rota na reserva
                Button(
                    onClick = onRepeatRide,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NovaOrangePrimary,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("btn_repeat_trip_${ride.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Replay,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Repetir Viagem",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * Diálogo com a ficha detalhada da corrida selecionada.
 */
@Composable
fun RideDetailsDialog(
    ride: RideHistoryItem,
    onDismiss: () -> Unit,
    onRepeatRide: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Detalhes da Corrida",
                    fontWeight = FontWeight.Black,
                    fontSize = 17.sp
                )
                Text(
                    text = ride.id,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NovaTextSecondary
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Card do Motorista e Veículo
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NovaOrangeLight.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = NovaOrangePrimary,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = ride.driverName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = NovaTextPrimary
                                )
                                Text(
                                    text = "★ ${ride.driverRating}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NovaOrangeDark
                                )
                            }
                            Text(
                                text = "${ride.vehicleModel} (${ride.vehiclePlate})",
                                fontSize = 11.sp,
                                color = NovaTextSecondary
                            )
                        }
                    }
                }

                // Resumo do Trajeto Completo
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NovaBackground,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "TRAJETO REALIZADO",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NovaTextSecondary
                        )

                        Row(
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.TripOrigin,
                                contentDescription = null,
                                tint = NovaSuccess,
                                modifier = Modifier.size(16.dp).padding(top = 2.dp)
                            )
                            Column {
                                Text(ride.origin.name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(ride.origin.address, fontSize = 10.sp, color = NovaTextSecondary)
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Place,
                                contentDescription = null,
                                tint = NovaOrangePrimary,
                                modifier = Modifier.size(16.dp).padding(top = 2.dp)
                            )
                            Column {
                                Text(ride.destination.name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(ride.destination.address, fontSize = 10.sp, color = NovaTextSecondary)
                            }
                        }
                    }
                }

                // Informações Financeiras e de Pagamento
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NovaBackground,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Distância percorrida:", fontSize = 11.sp, color = NovaTextSecondary)
                            Text(ride.formattedDistance, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Tempo de viagem:", fontSize = 11.sp, color = NovaTextSecondary)
                            Text(ride.formattedDuration, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Método de pagamento:", fontSize = 11.sp, color = NovaTextSecondary)
                            Text(ride.paymentMethod, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        HorizontalDivider(color = NovaCardBorder, thickness = 0.5.dp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total Pago:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                ride.formattedFare,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = NovaOrangePrimary
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onRepeatRide,
                colors = ButtonDefaults.buttonColors(containerColor = NovaOrangePrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("btn_repeat_ride")
            ) {
                Icon(
                    imageVector = Icons.Default.Replay,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Repetir este Trajeto", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Fechar")
            }
        }
    )
}
