package com.example.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = NovaOrangePrimary,
    onPrimary = Color.White,
    primaryContainer = NovaOrangeLight,
    onPrimaryContainer = NovaOrangeDark,
    secondary = NovaBlack,
    onSecondary = Color.White,
    background = NovaBackground,
    surface = NovaSurface,
    onBackground = NovaTextPrimary,
    onSurface = NovaTextPrimary
)

@Composable
fun NovaTaxiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
