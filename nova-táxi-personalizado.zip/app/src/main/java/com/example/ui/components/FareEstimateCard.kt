package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsBike
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FareEstimate
import com.example.model.LuandaPlace
import com.example.model.ServiceType
import com.example.model.TrafficCondition
import com.example.ui.theme.*
import com.example.viewmodel.FareUiState

@Composable
fun FareEstimateCard(
    fareState: FareUiState,
    places: List<LuandaPlace>,
    onSelectServiceType: (ServiceType) -> Unit,
    onSelectOrigin: (LuandaPlace) -> Unit,
    onSelectDestination: (LuandaPlace) -> Unit,
    onSwapLocations: () -> Unit,
    onSelectTrafficCondition: (TrafficCondition) -> Unit,
    onUseCurrentLocationForOrigin: () -> Unit,
    onOrderRide: (FareEstimate) -> Unit,
    modifier: Modifier = Modifier
) {
    var showOriginPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }
    var showCostBreakdown by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("fare_estimate_card"),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp, bottomStart = 20.dp, bottomEnd = 20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Seletor de Origem e Destino com botão de Inversão
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = NovaBackground,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Linha Origem
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showOriginPicker = true }
                                .testTag("origin_selector_row"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(NovaSuccess)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "PONTO DE PARTIDA",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NovaTextSecondary
                                )
                                Text(
                                    text = fareState.originTitle,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = NovaTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = "Escolher Origem",
                                tint = NovaTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        HorizontalDivider(color = NovaCardBorder, thickness = 0.5.dp)

                        // Linha Destino
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showDestPicker = true }
                                .testTag("destination_selector_row"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(NovaOrangePrimary)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "DESTINO EM LUANDA",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NovaTextSecondary
                                )
                                Text(
                                    text = fareState.destinationTitle,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = NovaTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = "Escolher Destino",
                                tint = NovaTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Botão Inverter Rota
                    IconButton(
                        onClick = onSwapLocations,
                        modifier = Modifier
                            .padding(start = 8.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(1.dp, NovaCardBorder, CircleShape)
                            .testTag("swap_route_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = "Inverter Origem e Destino",
                            tint = NovaOrangePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Seleção de Modalidade: Táxi vs Bike (Comparativo Direto)
            Text(
                text = "Escolha o tipo de serviço:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = NovaTextSecondary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Opção Táxi
                val isTaxi = fareState.selectedServiceType == ServiceType.TAXI
                val taxiEstimate = fareState.taxiEstimate

                ServiceOptionCard(
                    serviceType = ServiceType.TAXI,
                    isSelected = isTaxi,
                    estimate = taxiEstimate,
                    onSelect = { onSelectServiceType(ServiceType.TAXI) },
                    modifier = Modifier.weight(1f),
                    testTag = "select_service_taxi"
                )

                // Opção Bike
                val isBike = fareState.selectedServiceType == ServiceType.BIKE
                val bikeEstimate = fareState.bikeEstimate

                ServiceOptionCard(
                    serviceType = ServiceType.BIKE,
                    isSelected = isBike,
                    estimate = bikeEstimate,
                    onSelect = { onSelectServiceType(ServiceType.BIKE) },
                    modifier = Modifier.weight(1f),
                    testTag = "select_service_bike"
                )

                // Opção Entrega
                val isDelivery = fareState.selectedServiceType == ServiceType.DELIVERY
                val deliveryEstimate = fareState.deliveryEstimate

                ServiceOptionCard(
                    serviceType = ServiceType.DELIVERY,
                    isSelected = isDelivery,
                    estimate = deliveryEstimate,
                    onSelect = { onSelectServiceType(ServiceType.DELIVERY) },
                    modifier = Modifier.weight(1f),
                    testTag = "select_service_delivery"
                )
            }

            // Condição de Trânsito / Hora de Ponta (Surge Pricing)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Condição da Via:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = NovaTextSecondary
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TrafficCondition.entries.forEach { condition ->
                        val isSelected = fareState.trafficCondition == condition
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectTrafficCondition(condition) },
                            label = {
                                Text(
                                    text = condition.label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NovaOrangeLight,
                                selectedLabelColor = NovaOrangeDark
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) NovaOrangePrimary else NovaCardBorder
                            ),
                            modifier = Modifier.testTag("traffic_chip_${condition.name.lowercase()}")
                        )
                    }
                }
            }

            // Exibição da estimativa do serviço selecionado e decomposição
            fareState.currentEstimate?.let { estimate ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = NovaOrangeLight.copy(alpha = 0.5f),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(NovaOrangePrimary.copy(alpha = 0.3f))),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Tarifa Estimada (${estimate.serviceType.title})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NovaOrangeDark
                                )
                                Text(
                                    text = estimate.formattedTotalFare,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = NovaTextPrimary
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color.White
                                ) {
                                    Text(
                                        text = "${estimate.formattedDistance} • ${estimate.formattedDuration}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NovaTextPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { showCostBreakdown = !showCostBreakdown },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = if (showCostBreakdown) Icons.Default.ExpandLess else Icons.Default.Info,
                                        contentDescription = "Ver Detalhes do Cálculo",
                                        tint = NovaOrangePrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        // Decomposição detalhada dos custos do algoritmo
                        AnimatedVisibility(visible = showCostBreakdown) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                HorizontalDivider(color = NovaOrangePrimary.copy(alpha = 0.2f), thickness = 0.5.dp)

                                FareBreakdownRow("Bandeirada Base:", estimate.formattedBaseFare)
                                FareBreakdownRow("Distância estimada (${estimate.formattedDistance}):", estimate.formattedDistanceFare)
                                FareBreakdownRow("Tempo no trânsito (${estimate.formattedDuration}):", estimate.formattedTimeFare)

                                if (estimate.trafficCondition != TrafficCondition.NORMAL) {
                                    FareBreakdownRow(
                                        "Fator de Tráfego (${estimate.trafficCondition.label}):",
                                        "${((estimate.surgeMultiplier - 1.0) * 100).toInt()}% adicional"
                                    )
                                }

                                if (estimate.isMinimumFareApplied) {
                                    FareBreakdownRow(
                                        "Ajuste de Tarifa Mínima:",
                                        "Aplicada tarifa mínima do serviço"
                                    )
                                }

                                Text(
                                    text = "* Distância calculada pela malha viária urbana de Luanda (coeficiente 1.28x sobre linha reta geodésica).",
                                    fontSize = 9.sp,
                                    color = NovaTextSecondary,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Botão de Confirmação da Corrida
                Button(
                    onClick = { onOrderRide(estimate) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("order_ride_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NovaOrangePrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = when (estimate.serviceType) {
                            ServiceType.TAXI -> Icons.Default.DirectionsCar
                            ServiceType.BIKE -> Icons.AutoMirrored.Filled.DirectionsBike
                            ServiceType.DELIVERY -> Icons.Default.DeliveryDining
                        },
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Solicitar ${estimate.serviceType.title} • ${estimate.formattedTotalFare}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } ?: run {
                // Mensagem quando não há cálculo ativo ou erro
                if (fareState.errorMessage != null) {
                    Text(
                        text = fareState.errorMessage,
                        fontSize = 12.sp,
                        color = NovaError,
                        fontWeight = FontWeight.Medium
                    )
                } else if (fareState.isCalculating) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            color = NovaOrangePrimary,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("A calcular melhor tarifa em Luanda...", fontSize = 12.sp, color = NovaTextSecondary)
                    }
                }
            }
        }
    }

    // Modal de Seleção de Ponto de Partida
    if (showOriginPicker) {
        PlaceSelectionDialog(
            title = "Selecione o Ponto de Partida",
            places = places,
            onSelectPlace = { place ->
                onSelectOrigin(place)
                showOriginPicker = false
            },
            onUseGps = {
                onUseCurrentLocationForOrigin()
                showOriginPicker = false
            },
            onDismiss = { showOriginPicker = false }
        )
    }

    // Modal de Seleção de Destino
    if (showDestPicker) {
        PlaceSelectionDialog(
            title = "Selecione o Destino em Luanda",
            places = places,
            onSelectPlace = { place ->
                onSelectDestination(place)
                showDestPicker = false
            },
            onUseGps = null,
            onDismiss = { showDestPicker = false }
        )
    }
}

@Composable
private fun ServiceOptionCard(
    serviceType: ServiceType,
    isSelected: Boolean,
    estimate: FareEstimate?,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) NovaOrangeLight else NovaBackground,
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (isSelected) NovaOrangePrimary else NovaCardBorder
            )
        ),
        modifier = modifier
            .clickable { onSelect() }
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = when (serviceType) {
                        ServiceType.TAXI -> Icons.Default.DirectionsCar
                        ServiceType.BIKE -> Icons.AutoMirrored.Filled.DirectionsBike
                        ServiceType.DELIVERY -> Icons.Default.DeliveryDining
                    },
                    contentDescription = serviceType.title,
                    tint = if (isSelected) NovaOrangePrimary else NovaTextSecondary,
                    modifier = Modifier.size(24.dp)
                )

                Surface(
                    shape = CircleShape,
                    color = if (isSelected) NovaOrangePrimary else Color.Transparent,
                    modifier = Modifier.size(16.dp)
                ) {
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Selecionado",
                            tint = Color.White,
                            modifier = Modifier.padding(2.dp)
                        )
                    }
                }
            }

            Text(
                text = serviceType.title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = NovaTextPrimary
            )

            Text(
                text = if (serviceType == ServiceType.DELIVERY) {
                    "Carga • ${estimate?.formattedDuration ?: "Rápido"}"
                } else {
                    "${serviceType.capacitySeats} lug. • ${estimate?.formattedDuration ?: "${(serviceType.averageSpeedKmh).toInt()} km/h"}"
                },
                fontSize = 10.sp,
                color = NovaTextSecondary
            )

            Text(
                text = estimate?.formattedTotalFare ?: "A calcular...",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = if (isSelected) NovaOrangeDark else NovaTextPrimary
            )
        }
    }
}

@Composable
private fun FareBreakdownRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = NovaTextSecondary)
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = NovaTextPrimary)
    }
}

@Composable
private fun PlaceSelectionDialog(
    title: String,
    places: List<LuandaPlace>,
    onSelectPlace: (LuandaPlace) -> Unit,
    onUseGps: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (onUseGps != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onUseGps() }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MyLocation,
                            contentDescription = "GPS",
                            tint = NovaSuccess,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text("Usar Minha Posição GPS", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NovaSuccess)
                            Text("Localização em tempo real do passageiro", fontSize = 10.sp, color = NovaTextSecondary)
                        }
                    }
                    HorizontalDivider(color = NovaCardBorder, thickness = 0.5.dp)
                }

                places.forEach { place ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectPlace(place) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = null,
                            tint = NovaOrangePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(place.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(place.district, fontSize = 11.sp, color = NovaTextSecondary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
