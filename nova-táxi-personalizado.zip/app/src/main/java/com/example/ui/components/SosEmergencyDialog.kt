package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EmergencyContact
import com.example.ui.theme.*
import com.example.util.EmergencyHelper
import com.example.viewmodel.LocationUiState

/**
 * Diálogo de confirmação e disparo do Alerta SOS com partilha de localização GPS por SMS.
 */
@Composable
fun SosEmergencyDialog(
    locationState: LocationUiState,
    emergencyContact: EmergencyContact,
    onUpdateEmergencyContact: (EmergencyContact) -> Unit,
    onSendSms: (phoneNumber: String, message: String) -> Unit,
    onDialEmergency: (phoneNumber: String) -> Unit,
    onDismiss: () -> Unit
) {
    var isEditingContact by remember { mutableStateOf(false) }
    var contactName by remember { mutableStateOf(emergencyContact.name) }
    var contactPhone by remember { mutableStateOf(emergencyContact.phone) }

    val sosMessage = remember(locationState.latitude, locationState.longitude, locationState.accuracyMeters, locationState.nearestPlace) {
        EmergencyHelper.buildSosMessage(
            latitude = locationState.latitude,
            longitude = locationState.longitude,
            accuracyMeters = locationState.accuracyMeters,
            nearestPlaceName = locationState.nearestPlace?.name
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Surface(
                shape = CircleShape,
                color = Color(0xFFFEE2E2),
                modifier = Modifier.size(52.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Emergência SOS",
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        },
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "🚨 EMERGÊNCIA SOS",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = Color(0xFFDC2626)
                )
                Text(
                    text = "Partilha de Localização GPS em Tempo Real",
                    fontSize = 11.sp,
                    color = NovaTextSecondary
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Cartão de Informação de Localização GPS Atual
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (locationState.latitude != null) NovaOrangeLight.copy(alpha = 0.5f) else Color(0xFFFEF3C7),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(
                            if (locationState.latitude != null) NovaOrangePrimary.copy(alpha = 0.4f) else Color(0xFFF59E0B)
                        )
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = if (locationState.latitude != null) Icons.Default.GpsFixed else Icons.Default.GpsNotFixed,
                                contentDescription = null,
                                tint = if (locationState.latitude != null) NovaSuccess else Color(0xFFD97706),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (locationState.latitude != null) "GPS EM TEMPO REAL DETETADO" else "A PROCURAR SINAL GPS...",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (locationState.latitude != null) NovaSuccess else Color(0xFFB45309)
                            )
                        }

                        if (locationState.latitude != null && locationState.longitude != null) {
                            Text(
                                text = "Coordenadas: ${String.format("%.5f, %.5f", locationState.latitude, locationState.longitude)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NovaTextPrimary
                            )
                            locationState.nearestPlace?.let { place ->
                                Text(
                                    text = "Zona: ${place.name} (${place.district}, Luanda)",
                                    fontSize = 11.sp,
                                    color = NovaTextSecondary
                                )
                            }
                        } else {
                            Text(
                                text = "A mensagem incluirá as últimas coordenadas disponíveis em Luanda.",
                                fontSize = 11.sp,
                                color = NovaTextSecondary
                            )
                        }
                    }
                }

                // Contacto de Emergência Pré-definido
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NovaBackground,
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(NovaCardBorder)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContactPhone,
                                    contentDescription = null,
                                    tint = NovaOrangePrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "DESTINATÁRIO DO SOS",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NovaTextSecondary
                                )
                            }

                            TextButton(
                                onClick = { isEditingContact = !isEditingContact },
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text(
                                    text = if (isEditingContact) "Fechar" else "Alterar",
                                    fontSize = 11.sp,
                                    color = NovaOrangePrimary
                                )
                            }
                        }

                        if (!isEditingContact) {
                            Text(
                                text = emergencyContact.name,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = NovaTextPrimary
                            )
                            Text(
                                text = emergencyContact.phone,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NovaOrangeDark
                            )
                        } else {
                            // Campos de edição do contacto de emergência
                            OutlinedTextField(
                                value = contactName,
                                onValueChange = { contactName = it },
                                label = { Text("Nome do Contacto", fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                            )
                            OutlinedTextField(
                                value = contactPhone,
                                onValueChange = { contactPhone = it },
                                label = { Text("Número de Telefone", fontSize = 11.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                            )
                            Button(
                                onClick = {
                                    val updated = emergencyContact.copy(name = contactName, phone = contactPhone)
                                    onUpdateEmergencyContact(updated)
                                    isEditingContact = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NovaOrangePrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().height(36.dp)
                            ) {
                                Text("Guardar Contacto", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Ações Rápidas: Chamar Polícia (111) ou Enviar SMS
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { onDialEmergency("111") },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFDC2626))
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_dial_police_111")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ligar 111", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            onSendSms(emergencyContact.phone, sosMessage)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.4f)
                            .testTag("btn_confirm_sos_sms")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sms,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Enviar SMS SOS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_dismiss_sos")
            ) {
                Text("Cancelar", color = NovaTextSecondary)
            }
        }
    )
}
