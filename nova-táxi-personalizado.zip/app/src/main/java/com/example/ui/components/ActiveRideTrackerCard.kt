package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PassengerActiveRide
import com.example.model.PassengerRideStage
import com.example.model.ServiceType
import com.example.ui.theme.*

/**
 * Banner superior animado para avisos urgentes (ex: motorista a chegar ao local de partida).
 */
@Composable
fun DriverArrivalAlertBanner(
    message: String?,
    onOpenChat: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = !message.isNullOrBlank(),
        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        modifier = modifier
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = NovaOrangePrimary,
            shadowElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("driver_arrival_banner")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Alerta de Notificação",
                            tint = NovaOrangePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Aviso da Corrida",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                    Text(
                        text = message ?: "",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                FilledTonalButton(
                    onClick = onOpenChat,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color.White,
                        contentColor = NovaOrangePrimary
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("banner_btn_open_chat")
                ) {
                    Text("Chat", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(28.dp).testTag("banner_btn_dismiss")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Fechar alerta",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * Cartão interativo de acompanhamento da corrida do passageiro em tempo real.
 * Mostra status do motorista, ETA, veículo, botões de ação e simuladores de notificação.
 */
@Composable
fun ActiveRideTrackerCard(
    ride: PassengerActiveRide,
    onOpenChat: () -> Unit,
    onTriggerArriving: () -> Unit,
    onTriggerArrived: () -> Unit,
    onStartTrip: () -> Unit,
    onCompleteRide: () -> Unit,
    onCancelRide: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Animação de pulso quando o motorista está a chegar ou acabou de chegar
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val borderAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "border_alpha"
    )

    val borderColor = when (ride.stage) {
        PassengerRideStage.DRIVER_ARRIVING -> NovaOrangePrimary.copy(alpha = borderAlpha)
        PassengerRideStage.DRIVER_ARRIVED -> NovaSuccess.copy(alpha = borderAlpha)
        else -> NovaCardBorder
    }

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(borderColor)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("active_ride_tracker_card")
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Cabeçalho de Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when (ride.stage) {
                        PassengerRideStage.DRIVER_ASSIGNED -> Color(0xFFFFF3E0)
                        PassengerRideStage.DRIVER_ARRIVING -> Color(0xFFFFE0B2)
                        PassengerRideStage.DRIVER_ARRIVED -> Color(0xFFE8F5E9)
                        PassengerRideStage.IN_TRANSIT -> Color(0xFFE3F2FD)
                        else -> NovaBackground
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = when (ride.stage) {
                                PassengerRideStage.DRIVER_ASSIGNED -> Icons.Default.DirectionsCar
                                PassengerRideStage.DRIVER_ARRIVING -> Icons.Default.NearMe
                                PassengerRideStage.DRIVER_ARRIVED -> Icons.Default.CheckCircle
                                PassengerRideStage.IN_TRANSIT -> Icons.Default.Navigation
                                else -> Icons.Default.Info
                            },
                            contentDescription = null,
                            tint = when (ride.stage) {
                                PassengerRideStage.DRIVER_ASSIGNED -> NovaOrangePrimary
                                PassengerRideStage.DRIVER_ARRIVING -> Color(0xFFE65100)
                                PassengerRideStage.DRIVER_ARRIVED -> NovaSuccess
                                PassengerRideStage.IN_TRANSIT -> Color(0xFF1565C0)
                                else -> NovaTextSecondary
                            },
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = ride.stage.label,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = when (ride.stage) {
                                PassengerRideStage.DRIVER_ASSIGNED -> NovaOrangePrimary
                                PassengerRideStage.DRIVER_ARRIVING -> Color(0xFFE65100)
                                PassengerRideStage.DRIVER_ARRIVED -> NovaSuccess
                                PassengerRideStage.IN_TRANSIT -> Color(0xFF1565C0)
                                else -> NovaTextSecondary
                            }
                        )
                    }
                }

                // ETA / Tempo restante
                if (ride.stage != PassengerRideStage.DRIVER_ARRIVED && ride.stage != PassengerRideStage.COMPLETED) {
                    Text(
                        text = "${ride.etaMinutes} min restantes",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = NovaOrangePrimary
                    )
                } else if (ride.stage == PassengerRideStage.DRIVER_ARRIVED) {
                    Text(
                        text = "NO PONTO DE PARTIDA",
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        color = NovaSuccess
                    )
                }
            }

            // Cartão de Destaque quando o motorista está a chegar ou chegou
            if (ride.stage == PassengerRideStage.DRIVER_ARRIVING) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFFFFF8E1),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFFFB300))
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("status_alert_arriving")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = Color(0xFFF57C00),
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "Atenção: Motorista a ${ride.etaMinutes} min do seu local!",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFFE65100)
                            )
                            Text(
                                text = "Notificação local enviada. Prepare-se em ${ride.originAddress}.",
                                fontSize = 11.sp,
                                color = NovaTextSecondary
                            )
                        }
                    }
                }
            } else if (ride.stage == PassengerRideStage.DRIVER_ARRIVED) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFFE8F5E9),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(NovaSuccess)
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("status_alert_arrived")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = NovaSuccess,
                            modifier = Modifier.size(26.dp)
                        )
                        Column {
                            Text(
                                text = "O motorista já chegou ao local!",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF1B5E20)
                            )
                            Text(
                                text = "${ride.vehicleModel} (${ride.vehiclePlate}) à sua espera.",
                                fontSize = 12.sp,
                                color = Color(0xFF2E7D32)
                            )
                        }
                    }
                }
            }

            // Informações do Motorista e Veículo
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = NovaOrangePrimary,
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = when (ride.serviceType) {
                                ServiceType.TAXI -> Icons.Default.DirectionsCar
                                ServiceType.BIKE -> Icons.Default.TwoWheeler
                                ServiceType.DELIVERY -> Icons.Default.DeliveryDining
                            },
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = ride.driverName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = NovaTextPrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFFF9C4)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = Color(0xFFF57F17),
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "${ride.driverRating}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF5D4037)
                                )
                            }
                        }
                    }

                    Text(
                        text = "${ride.vehicleModel} • ${ride.vehiclePlate}",
                        fontSize = 12.sp,
                        color = NovaTextSecondary,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = "Recolha: ${ride.originAddress}",
                        fontSize = 11.sp,
                        color = NovaTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Valor total da corrida
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = ride.formattedFare,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = NovaOrangePrimary
                    )
                    Text(
                        text = "Estimado",
                        fontSize = 10.sp,
                        color = NovaTextSecondary
                    )
                }
            }

            HorizontalDivider(color = NovaCardBorder, thickness = 0.5.dp)

            // Ações de Comunicação Direta (Chat e Chamada)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpenChat,
                    modifier = Modifier.weight(1f).testTag("btn_ride_chat"),
                    colors = ButtonDefaults.buttonColors(containerColor = NovaOrangePrimary),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Chat com Motorista", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                data = Uri.parse("tel:${ride.driverPhone}")
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    modifier = Modifier.testTag("btn_ride_call"),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Ligar",
                        tint = NovaOrangePrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Barra de simulação rápida para demonstração e testes do utilizador
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = NovaBackground,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Simulador de Alerta de Chegada:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NovaTextSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilledTonalButton(
                            onClick = onTriggerArriving,
                            enabled = ride.stage == PassengerRideStage.DRIVER_ASSIGNED,
                            modifier = Modifier.weight(1f).testTag("btn_simulate_arriving"),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text("A Chegar (2 min)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        FilledTonalButton(
                            onClick = onTriggerArrived,
                            enabled = ride.stage == PassengerRideStage.DRIVER_ARRIVING || ride.stage == PassengerRideStage.DRIVER_ASSIGNED,
                            modifier = Modifier.weight(1f).testTag("btn_simulate_arrived"),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text("Chegou ao Local", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        if (ride.stage == PassengerRideStage.DRIVER_ARRIVED) {
                            Button(
                                onClick = onStartTrip,
                                colors = ButtonDefaults.buttonColors(containerColor = NovaSuccess),
                                modifier = Modifier.weight(1f).testTag("btn_start_trip"),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Text("Embarcar", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = onCancelRide,
                            modifier = Modifier.testTag("btn_cancel_ride")
                        ) {
                            Text("Cancelar Corrida", fontSize = 11.sp, color = Color.Red)
                        }

                        if (ride.stage == PassengerRideStage.IN_TRANSIT || ride.stage == PassengerRideStage.DRIVER_ARRIVED) {
                            TextButton(
                                onClick = onCompleteRide,
                                modifier = Modifier.testTag("btn_finish_ride")
                            ) {
                                Text("Concluir Viagem", fontSize = 11.sp, color = NovaSuccess, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
