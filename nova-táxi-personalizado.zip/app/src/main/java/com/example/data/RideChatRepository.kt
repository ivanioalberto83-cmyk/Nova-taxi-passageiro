package com.example.data

import com.example.model.ChatMessage
import com.example.model.MessageSenderRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Repositório centralizado de mensagens de chat em tempo real entre o motorista e o passageiro.
 * Utiliza Kotlin Coroutines e StateFlow para comunicação pub/sub instantânea e bidirecional.
 */
object RideChatRepository {

    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _messages = MutableStateFlow<List<ChatMessage>>(initialConversation())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    val unreadCountForPassenger: StateFlow<Int> = _messages.map { list ->
        list.count { it.senderRole == MessageSenderRole.DRIVER && !it.isRead }
    }.stateIn(repositoryScope, SharingStarted.Eagerly, 0)

    val unreadCountForDriver: StateFlow<Int> = _messages.map { list ->
        list.count { it.senderRole == MessageSenderRole.PASSENGER && !it.isRead }
    }.stateIn(repositoryScope, SharingStarted.Eagerly, 0)

    private fun initialConversation(): List<ChatMessage> {
        val now = System.currentTimeMillis()
        return listOf(
            ChatMessage(
                senderRole = MessageSenderRole.SYSTEM,
                senderName = "Sistema NOVA Táxi",
                text = "Corrida em andamento. Combine o ponto exato de embarque pelo chat.",
                timestamp = now - 90000,
                isRead = true
            ),
            ChatMessage(
                senderRole = MessageSenderRole.DRIVER,
                senderName = "Bernardo Kiala (Motorista)",
                text = "Olá! Já aceitei a sua corrida e estou a caminho. Alguma referência do local?",
                timestamp = now - 60000,
                isRead = false
            )
        )
    }

    /**
     * Envia uma nova mensagem no chat em tempo real.
     */
    fun sendMessage(
        senderRole: MessageSenderRole,
        senderName: String,
        text: String,
        autoReply: Boolean = true
    ) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return

        val message = ChatMessage(
            senderRole = senderRole,
            senderName = senderName,
            text = trimmed,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )

        _messages.update { it + message }

        // Se o passageiro enviou e a resposta automática estiver habilitada, simula o motorista a responder
        if (senderRole == MessageSenderRole.PASSENGER && autoReply) {
            scheduleSimulatedDriverResponse(trimmed)
        } else if (senderRole == MessageSenderRole.DRIVER && autoReply) {
            scheduleSimulatedPassengerResponse(trimmed)
        }
    }

    private fun scheduleSimulatedDriverResponse(passengerText: String) {
        repositoryScope.launch {
            delay(1800) // Delay realista de digitação e trânsito
            val replyText = generateDriverReply(passengerText)
            val driverMsg = ChatMessage(
                senderRole = MessageSenderRole.DRIVER,
                senderName = "Bernardo Kiala (Motorista)",
                text = replyText,
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
            _messages.update { it + driverMsg }
        }
    }

    private fun scheduleSimulatedPassengerResponse(driverText: String) {
        repositoryScope.launch {
            delay(1600)
            val replyText = generatePassengerReply(driverText)
            val passengerMsg = ChatMessage(
                senderRole = MessageSenderRole.PASSENGER,
                senderName = "Ivânio Alberto (Passageiro)",
                text = replyText,
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
            _messages.update { it + passengerMsg }
        }
    }

    private fun generateDriverReply(text: String): String {
        val lower = text.lowercase()
        return when {
            lower.contains("onde") || lower.contains("cadê") ->
                "Estou a cerca de 300 metros, passando a rotunda com pisca-alerta ligado!"
            lower.contains("chegando") || lower.contains("descer") || lower.contains("já vou") ->
                "Perfeito! Já estou encostado à direita, aguardo com calma."
            lower.contains("azul") || lower.contains("roupa") || lower.contains("camisa") ->
                "Excelente referência, já visualizei. Estou num Toyota Corolla cinzento."
            lower.contains("banco") || lower.contains("shopping") || lower.contains("porta") || lower.contains("frente") ->
                "Entendido! Estou mesmo em frente à entrada principal."
            lower.contains("obrigado") || lower.contains("valeu") ->
                "De nada! Tenha uma excelente viagem connosco."
            else ->
                "Entendido! Estou atento e chego em breve ao ponto marcado."
        }
    }

    private fun generatePassengerReply(text: String): String {
        val lower = text.lowercase()
        return when {
            lower.contains("caminho") || lower.contains("chegando") ->
                "Ok, obrigado! Já estou cá fora à espera."
            lower.contains("cheguei") || lower.contains("local") || lower.contains("encostado") ->
                "Já te vi! Estou a caminhar em direção ao carro."
            lower.contains("trânsito") || lower.contains("engarrafamento") ->
                "Sem problema, aqui na zona de Luanda o trânsito costuma complicar. Aguardo!"
            else ->
                "Confirmado, muito obrigado pelo aviso!"
        }
    }

    /**
     * Marca mensagens como lidas para o utilizador atual.
     */
    fun markAsRead(forRole: MessageSenderRole) {
        _messages.update { list ->
            list.map { msg ->
                if (msg.senderRole != forRole && !msg.isRead) {
                    msg.copy(isRead = true)
                } else {
                    msg
                }
            }
        }
    }

    /**
     * Reinicia ou inicializa uma nova sessão de chat para uma nova corrida.
     */
    fun resetForNewRide(passengerName: String, driverName: String) {
        val now = System.currentTimeMillis()
        _messages.value = listOf(
            ChatMessage(
                senderRole = MessageSenderRole.SYSTEM,
                senderName = "Sistema NOVA Táxi",
                text = "Corrida iniciada com sucesso entre $passengerName e $driverName.",
                timestamp = now,
                isRead = true
            ),
            ChatMessage(
                senderRole = MessageSenderRole.DRIVER,
                senderName = "$driverName (Motorista)",
                text = "Olá $passengerName! Já estou a caminho da sua recolha. Qualquer dúvida pode escrever aqui.",
                timestamp = now + 500,
                isRead = false
            )
        )
    }
}
