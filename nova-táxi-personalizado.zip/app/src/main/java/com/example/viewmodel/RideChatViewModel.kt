package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.RideChatRepository
import com.example.model.ChatMessage
import com.example.model.MessageSenderRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * ViewModel para gerenciar o estado da tela e componente de Chat em Tempo Real.
 */
class RideChatViewModel : ViewModel() {

    private val repository = RideChatRepository

    val messages: StateFlow<List<ChatMessage>> = repository.messages
    val unreadCountForPassenger: StateFlow<Int> = repository.unreadCountForPassenger
    val unreadCountForDriver: StateFlow<Int> = repository.unreadCountForDriver

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    val quickPassengerSuggestions = listOf(
        "Estou no ponto de recolha",
        "Onde você está?",
        "Estou de camisa azul",
        "Pode ligar o pisca-alerta?",
        "Já estou a descer!"
    )

    val quickDriverSuggestions = listOf(
        "Já estou a caminho!",
        "Cheguei ao local combinado",
        "Estou com pisca-alerta ligado",
        "Trânsito pesado, chego em 3 min",
        "Pode embarcar com calma!"
    )

    fun onInputTextChanged(text: String) {
        _inputText.value = text
    }

    /**
     * Envia o texto digitado pelo utilizador (Passageiro ou Motorista).
     */
    fun sendMessage(role: MessageSenderRole, senderName: String) {
        val currentText = _inputText.value
        if (currentText.isBlank()) return

        repository.sendMessage(
            senderRole = role,
            senderName = senderName,
            text = currentText
        )
        _inputText.value = ""
    }

    /**
     * Envia uma sugestão rápida predefinida com 1 toque.
     */
    fun sendQuickSuggestion(role: MessageSenderRole, senderName: String, suggestion: String) {
        repository.sendMessage(
            senderRole = role,
            senderName = senderName,
            text = suggestion
        )
    }

    /**
     * Marca mensagens como lidas para o papel ativo.
     */
    fun markAsRead(role: MessageSenderRole) {
        repository.markAsRead(role)
    }
}
