package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import com.example.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * ViewModel que gerencia o estado e persistência local do perfil do utilizador.
 */
class UserProfileViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("nova_taxi_user_profile", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(loadProfileFromPrefs())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private fun loadProfileFromPrefs(): UserProfile {
        return UserProfile(
            name = prefs.getString("profile_name", "Ivânio Alberto") ?: "Ivânio Alberto",
            phoneNumber = prefs.getString("profile_phone", "+244 923 456 789") ?: "+244 923 456 789",
            email = prefs.getString("profile_email", "ivanioalberto83@gmail.com") ?: "ivanioalberto83@gmail.com",
            photoUri = prefs.getString("profile_photo_uri", null),
            rating = 4.97,
            totalRidesAsPassenger = prefs.getInt("profile_rides_count", 24),
            memberSince = "Outubro de 2024",
            preferredPaymentMethod = prefs.getString("profile_payment_method", "Multicaixa Express") ?: "Multicaixa Express"
        )
    }

    private fun persistProfile(profile: UserProfile) {
        prefs.edit().apply {
            putString("profile_name", profile.name)
            putString("profile_phone", profile.phoneNumber)
            putString("profile_email", profile.email)
            putString("profile_photo_uri", profile.photoUri)
            putInt("profile_rides_count", profile.totalRidesAsPassenger)
            putString("profile_payment_method", profile.preferredPaymentMethod)
            apply()
        }
    }

    /**
     * Atualiza o nome, telefone e email do utilizador.
     */
    fun saveProfile(name: String, phoneNumber: String, email: String): Boolean {
        val trimmedName = name.trim()
        val trimmedPhone = phoneNumber.trim()
        val trimmedEmail = email.trim()

        if (trimmedName.isBlank() || trimmedPhone.isBlank()) {
            return false
        }

        _userProfile.update { current ->
            val updated = current.copy(
                name = trimmedName,
                phoneNumber = trimmedPhone,
                email = trimmedEmail.ifBlank { current.email }
            )
            persistProfile(updated)
            updated
        }
        return true
    }

    /**
     * Atualiza a URI da foto do utilizador (obtida via Photo Picker).
     */
    fun updatePhotoUri(uriString: String?) {
        _userProfile.update { current ->
            val updated = current.copy(photoUri = uriString)
            persistProfile(updated)
            updated
        }
    }

    /**
     * Remove a foto de perfil personalizada.
     */
    fun removePhoto() {
        updatePhotoUri(null)
    }
}
