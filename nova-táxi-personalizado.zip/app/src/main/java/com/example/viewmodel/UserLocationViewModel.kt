package com.example.viewmodel

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Looper
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.LuandaPlace
import com.example.util.LuandaLocations
import com.google.android.gms.location.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Estado reativo da localização do passageiro/utilizador em tempo real.
 */
data class LocationUiState(
    val isLoading: Boolean = false,
    val currentLocation: Location? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val accuracyMeters: Float? = null,
    val altitudeMeters: Double? = null,
    val speedKmh: Float? = null,
    val bearingDegrees: Float? = null,
    val isTrackingActive: Boolean = false,
    val hasPermission: Boolean = false,
    val isGpsHardwareEnabled: Boolean = true,
    val nearestPlace: LuandaPlace? = null,
    val distanceToNearestKm: Double? = null,
    val lastUpdatedTimestamp: Long = 0L,
    val lastUpdatedFormatted: String = "A aguardar sinal...",
    val errorMessage: String? = null
)

/**
 * ViewModel centralizador da localização em tempo real da NOVA Táxi.
 * 
 * Utiliza o Google Play Services Location (FusedLocationProviderClient)
 * para obter atualizações contínuas de alta precisão com eficiência de bateria,
 * identificação do ponto de referência mais próximo em Luanda e fallback manual.
 */
class UserLocationViewModel : ViewModel() {

    private val TAG = "UserLocationViewModel"

    private val _uiState = MutableStateFlow(LocationUiState())
    val uiState: StateFlow<LocationUiState> = _uiState.asStateFlow()

    private var fusedLocationClient: FusedLocationProviderClient? = null
    private var locationCallback: LocationCallback? = null

    private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    /**
     * Inicializa o cliente FusedLocationProviderClient e verifica estado inicial.
     */
    fun initialize(context: Context) {
        if (fusedLocationClient == null) {
            fusedLocationClient = LocationServices.getFusedLocationProviderClient(context.applicationContext)
        }
        checkGpsHardwareStatus(context)
    }

    /**
     * Atualiza o estado da permissão de localização do Android e inicia/para a recolha.
     */
    fun onPermissionResult(isGranted: Boolean, context: Context) {
        _uiState.update { it.copy(hasPermission = isGranted) }
        if (isGranted) {
            fetchLastKnownLocation(context)
            startLocationUpdates(context)
        } else {
            stopLocationUpdates()
            _uiState.update {
                it.copy(
                    errorMessage = "Permissão de localização não concedida. Pode selecionar o local no mapa manualmente."
                )
            }
        }
    }

    /**
     * Inicia a receção contínua de coordenadas em tempo real com alta precisão.
     */
    @SuppressLint("MissingPermission")
    fun startLocationUpdates(context: Context) {
        initialize(context)

        if (!_uiState.value.hasPermission) {
            _uiState.update { it.copy(errorMessage = "Aguardando permissão de localização.") }
            return
        }

        if (_uiState.value.isTrackingActive) return

        _uiState.update { it.copy(isLoading = true, errorMessage = null) }

        // Configuração do pedido de localização em tempo real (Priority.PRIORITY_HIGH_ACCURACY)
        val locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            5000L // Intervalo ideal: 5 segundos
        ).apply {
            setMinUpdateIntervalMillis(2000L) // Intervalo mais rápido: 2 segundos
            setMinUpdateDistanceMeters(3f)     // Deslocação mínima: 3 metros
            setWaitForAccurateLocation(false)
        }.build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { location ->
                    processNewLocation(location)
                }
            }

            override fun onLocationAvailability(availability: LocationAvailability) {
                val available = availability.isLocationAvailable
                _uiState.update { it.copy(isGpsHardwareEnabled = available) }
                if (!available) {
                    Log.w(TAG, "Sinal GPS temporariamente indisponível.")
                }
            }
        }

        try {
            fusedLocationClient?.requestLocationUpdates(
                locationRequest,
                locationCallback!!,
                Looper.getMainLooper()
            )?.addOnSuccessListener {
                _uiState.update { it.copy(isTrackingActive = true, isLoading = false) }
                Log.i(TAG, "Atualizações de localização em tempo real iniciadas com sucesso.")
            }?.addOnFailureListener { e ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "Falha ao iniciar atualizações: ${e.localizedMessage}"
                    )
                }
                Log.e(TAG, "Falha ao registar LocationUpdates", e)
            }
        } catch (e: SecurityException) {
            _uiState.update {
                it.copy(isLoading = false, errorMessage = "Erro de segurança ao aceder ao GPS.")
            }
        }
    }

    /**
     * Para a receção de localização para poupar bateria e recursos do dispositivo.
     */
    fun stopLocationUpdates() {
        locationCallback?.let { callback ->
            fusedLocationClient?.removeLocationUpdates(callback)
            locationCallback = null
        }
        _uiState.update { it.copy(isTrackingActive = false, isLoading = false) }
        Log.i(TAG, "Atualizações de localização em tempo real paradas.")
    }

    /**
     * Alterna o estado de tracking ativo / inativo.
     */
    fun toggleTracking(context: Context) {
        if (_uiState.value.isTrackingActive) {
            stopLocationUpdates()
        } else {
            startLocationUpdates(context)
        }
    }

    /**
     * Obtém a última localização conhecida em cache (rápida).
     */
    @SuppressLint("MissingPermission")
    fun fetchLastKnownLocation(context: Context) {
        initialize(context)
        if (!_uiState.value.hasPermission) return

        try {
            fusedLocationClient?.lastLocation?.addOnSuccessListener { location ->
                if (location != null) {
                    processNewLocation(location)
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Permissão em falta ao obter lastLocation", e)
        }
    }

    /**
     * Processa uma nova coordenada GPS: calcula velocidade, precisão e ponto de Luanda mais próximo.
     */
    private fun processNewLocation(location: Location) {
        val lat = location.latitude
        val lng = location.longitude

        val nearest = LuandaLocations.findNearestPlace(lat, lng)
        val distanceKm = LuandaLocations.calculateDistanceKm(lat, lng, nearest.lat, nearest.lng)
        val speedKmh = if (location.hasSpeed()) (location.speed * 3.6f) else 0f
        val now = System.currentTimeMillis()

        _uiState.update {
            it.copy(
                isLoading = false,
                currentLocation = location,
                latitude = lat,
                longitude = lng,
                accuracyMeters = if (location.hasAccuracy()) location.accuracy else null,
                altitudeMeters = if (location.hasAltitude()) location.altitude else null,
                speedKmh = speedKmh,
                bearingDegrees = if (location.hasBearing()) location.bearing else null,
                nearestPlace = nearest,
                distanceToNearestKm = distanceKm,
                lastUpdatedTimestamp = now,
                lastUpdatedFormatted = timeFormatter.format(Date(now)),
                errorMessage = null
            )
        }
    }

    /**
     * Permite ao passageiro definir uma localização manual caso o GPS esteja indisponível.
     */
    fun setManualLocation(place: LuandaPlace) {
        val mockLoc = Location("Manual").apply {
            latitude = place.lat
            longitude = place.lng
            accuracy = 5f
            time = System.currentTimeMillis()
        }
        processNewLocation(mockLoc)
    }

    /**
     * Verifica se os serviços de GPS do dispositivo estão ativos.
     */
    fun checkGpsHardwareStatus(context: Context) {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        val isGpsEnabled = lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true ||
                lm?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true
        _uiState.update { it.copy(isGpsHardwareEnabled = isGpsEnabled) }
    }

    fun clearErrorMessage() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        stopLocationUpdates()
    }
}
