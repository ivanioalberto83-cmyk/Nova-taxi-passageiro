package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.FareEstimate
import com.example.model.LuandaPlace
import com.example.model.ServiceType
import com.example.model.TrafficCondition
import com.example.util.LuandaLocations
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.*

/**
 * Estado da estimativa de tarifa e rota selecionada.
 */
data class FareUiState(
    val origin: LuandaPlace? = null,
    val destination: LuandaPlace? = null,
    val originLat: Double = -8.8584, // Aeroporto 4 de Fevereiro por omissão
    val originLng: Double = 13.2312,
    val originTitle: String = "Aeroporto 4 de Fevereiro",
    val destinationLat: Double = -8.8105, // Marginal de Luanda por omissão
    val destinationLng: Double = 13.2389,
    val destinationTitle: String = "Marginal de Luanda / Baía",
    val selectedServiceType: ServiceType = ServiceType.TAXI,
    val trafficCondition: TrafficCondition = TrafficCondition.NORMAL,
    val taxiEstimate: FareEstimate? = null,
    val bikeEstimate: FareEstimate? = null,
    val deliveryEstimate: FareEstimate? = null,
    val isCalculating: Boolean = false,
    val errorMessage: String? = null
) {
    val currentEstimate: FareEstimate?
        get() = when (selectedServiceType) {
            ServiceType.TAXI -> taxiEstimate
            ServiceType.BIKE -> bikeEstimate
            ServiceType.DELIVERY -> deliveryEstimate
        }
}

/**
 * ViewModel responsável pelo cálculo da tarifa estimada de corrida na NOVA Táxi.
 * Suporta Táxi e Bike, ajustando por distância de rede rodoviária, duração e trânsito de Luanda.
 */
class FareCalculationViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(FareUiState())
    val uiState: StateFlow<FareUiState> = _uiState.asStateFlow()

    init {
        // Inicializa com origem e destino padrão de Luanda
        val defaultOrigin = LuandaLocations.defaultOrigin
        val defaultDest = LuandaLocations.defaultDestination
        setRoute(
            origin = defaultOrigin,
            destination = defaultDest
        )
    }

    /**
     * Define ambos origem e destino através de LuandaPlace.
     */
    fun setRoute(origin: LuandaPlace, destination: LuandaPlace) {
        _uiState.update {
            it.copy(
                origin = origin,
                destination = destination,
                originLat = origin.lat,
                originLng = origin.lng,
                originTitle = origin.name,
                destinationLat = destination.lat,
                destinationLng = destination.lng,
                destinationTitle = destination.name,
                errorMessage = null
            )
        }
        recalculateFares()
    }

    /**
     * Define o local de recolha (origem).
     */
    fun setOrigin(place: LuandaPlace) {
        _uiState.update {
            it.copy(
                origin = place,
                originLat = place.lat,
                originLng = place.lng,
                originTitle = place.name,
                errorMessage = null
            )
        }
        recalculateFares()
    }

    /**
     * Define as coordenadas de origem (por exemplo, obtidas via GPS em tempo real).
     */
    fun setOriginFromGps(lat: Double, lng: Double, title: String = "Minha Localização Atual") {
        val nearest = LuandaLocations.findNearestPlace(lat, lng)
        _uiState.update {
            it.copy(
                origin = nearest,
                originLat = lat,
                originLng = lng,
                originTitle = title,
                errorMessage = null
            )
        }
        recalculateFares()
    }

    /**
     * Define o local de destino.
     */
    fun setDestination(place: LuandaPlace) {
        _uiState.update {
            it.copy(
                destination = place,
                destinationLat = place.lat,
                destinationLng = place.lng,
                destinationTitle = place.name,
                errorMessage = null
            )
        }
        recalculateFares()
    }

    /**
     * Define coordenadas personalizadas de destino.
     */
    fun setDestinationCoordinates(lat: Double, lng: Double, title: String) {
        val nearest = LuandaLocations.findNearestPlace(lat, lng)
        _uiState.update {
            it.copy(
                destination = nearest,
                destinationLat = lat,
                destinationLng = lng,
                destinationTitle = title,
                errorMessage = null
            )
        }
        recalculateFares()
    }

    /**
     * Alterna a seleção entre Táxi e Bike.
     */
    fun selectServiceType(type: ServiceType) {
        _uiState.update { it.copy(selectedServiceType = type) }
    }

    /**
     * Atualiza a condição de trânsito simulada/observada em Luanda.
     */
    fun setTrafficCondition(condition: TrafficCondition) {
        _uiState.update { it.copy(trafficCondition = condition) }
        recalculateFares()
    }

    /**
     * Inverte a rota (origem vira destino e vice-versa).
     */
    fun swapOriginAndDestination() {
        _uiState.update { current ->
            current.copy(
                origin = current.destination,
                originLat = current.destinationLat,
                originLng = current.destinationLng,
                originTitle = current.destinationTitle,
                destination = current.origin,
                destinationLat = current.originLat,
                destinationLng = current.originLng,
                destinationTitle = current.originTitle
            )
        }
        recalculateFares()
    }

    /**
     * Recalcula as tarifas para todas as categorias de transporte disponíveis.
     */
    fun recalculateFares() {
        val state = _uiState.value
        val lat1 = state.originLat
        val lon1 = state.originLng
        val lat2 = state.destinationLat
        val lon2 = state.destinationLng
        val traffic = state.trafficCondition

        // Validação básica de distância
        if (lat1 == lat2 && lon1 == lon2) {
            _uiState.update {
                it.copy(
                    errorMessage = "A origem e o destino não podem ser iguais.",
                    taxiEstimate = null,
                    bikeEstimate = null,
                    deliveryEstimate = null
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isCalculating = true, errorMessage = null) }

            val taxi = calculateEstimate(
                lat1 = lat1,
                lon1 = lon1,
                lat2 = lat2,
                lon2 = lon2,
                serviceType = ServiceType.TAXI,
                trafficCondition = traffic
            )

            val bike = calculateEstimate(
                lat1 = lat1,
                lon1 = lon1,
                lat2 = lat2,
                lon2 = lon2,
                serviceType = ServiceType.BIKE,
                trafficCondition = traffic
            )

            val delivery = calculateEstimate(
                lat1 = lat1,
                lon1 = lon1,
                lat2 = lat2,
                lon2 = lon2,
                serviceType = ServiceType.DELIVERY,
                trafficCondition = traffic
            )

            _uiState.update {
                it.copy(
                    taxiEstimate = taxi,
                    bikeEstimate = bike,
                    deliveryEstimate = delivery,
                    isCalculating = false
                )
            }
        }
    }

    /**
     * Algoritmo de cálculo tarifário completo para a NOVA Táxi Angola:
     * 
     * 1. Distância Geodésica (Haversine): cálculo da curvatura da terra em km.
     * 2. Fator de Desvio de Malha Rodoviária Urbana: em Luanda, ruas e avenidas aumentam a distância
     *    em ~28% em relação à linha reta geodésica (fator 1.28).
     * 3. Duração da Viagem: baseada na velocidade média do modal ajustada pelo tráfego.
     * 4. Decomposição de Custos:
     *    - Tarifa Base (Bandeirada)
     *    - Custo por Distância (km * taxa/km)
     *    - Custo por Tempo (minutos * taxa/minuto)
     * 5. Multiplicador de tráfego/procura (surge pricing em hora de ponta).
     * 6. Aplicação da Tarifa Mínima do modal e arredondamento comercial a múltiplos de 50 Kz.
     */
    fun calculateEstimate(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double,
        serviceType: ServiceType,
        trafficCondition: TrafficCondition = TrafficCondition.NORMAL
    ): FareEstimate {
        // 1. Distância em linha reta (Haversine)
        val straightDistKm = calculateHaversineDistanceKm(lat1, lon1, lat2, lon2)

        // 2. Fator de malha viária urbana de Luanda (curvas, nós viários, contornos)
        val roadDetourFactor = 1.28
        val roadDistKm = max(0.5, (straightDistKm * roadDetourFactor * 10.0).roundToInt() / 10.0)

        // 3. Velocidade média ajustada à condição de tráfego
        val effectiveSpeedKmh = max(10.0, serviceType.averageSpeedKmh * trafficCondition.speedMultiplier)

        // 4. Estimativa de tempo em minutos (mínimo de 3 minutos)
        val durationHours = roadDistKm / effectiveSpeedKmh
        val durationMinutes = max(3, ceil(durationHours * 60.0).toInt())

        // 5. Componentes da tarifa
        val baseFare = serviceType.baseFareAoa
        val distanceFare = roadDistKm * serviceType.ratePerKmAoa
        val timeFare = durationMinutes * serviceType.ratePerMinuteAoa

        val subtotal = baseFare + distanceFare + timeFare

        // 6. Multiplicador de dinâmica/tráfego
        val rawTotal = subtotal * trafficCondition.surgeMultiplier

        // 7. Tarifa mínima e arredondamento a múltiplos de 50 Kz (prática comum em Angola)
        val roundedTotal = roundToNearest50(rawTotal)
        val isMinApplied = roundedTotal < serviceType.minimumFareAoa
        val finalFare = max(serviceType.minimumFareAoa, roundedTotal)

        return FareEstimate(
            serviceType = serviceType,
            straightLineDistanceKm = straightDistKm,
            roadDistanceKm = roadDistKm,
            estimatedDurationMinutes = durationMinutes,
            baseFareAoa = baseFare,
            distanceFareAoa = distanceFare,
            timeFareAoa = timeFare,
            trafficCondition = trafficCondition,
            surgeMultiplier = trafficCondition.surgeMultiplier,
            subtotalAoa = subtotal,
            isMinimumFareApplied = isMinApplied,
            totalFareAoa = finalFare
        )
    }

    /**
     * Fórmula de Haversine para cálculo da distância geodésica em quilómetros.
     */
    private fun calculateHaversineDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadiusKm = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)

        val a = sin(dLat / 2).pow(2.0) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2.0)

        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return (earthRadiusKm * c * 100.0).roundToInt() / 100.0
    }

    /**
     * Arredonda valores para o múltiplo de 50 Kwanzas mais próximo.
     */
    private fun roundToNearest50(value: Double): Double {
        return (round(value / 50.0) * 50.0)
    }
}
