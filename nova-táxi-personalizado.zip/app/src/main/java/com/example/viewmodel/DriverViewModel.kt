package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.DriverRideRequest
import com.example.model.ServiceType
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Estado reativo do painel de disponibilidade do motorista.
 */
data class DriverUiState(
    val isOnline: Boolean = false,
    val driverName: String = "Bernardo Kiala",
    val vehicleModel: String = "Toyota Corolla 2021",
    val vehiclePlate: String = "LD-42-88-HA",
    val rating: Double = 4.96,
    val todayEarningsAoa: Double = 28500.0,
    val completedTripsToday: Int = 9,
    val onlineTimeFormatted: String = "5h 40m",
    val acceptanceRatePercent: Int = 94,
    val incomingRequest: DriverRideRequest? = null,
    val activeAcceptedRide: DriverRideRequest? = null,
    val acceptedServices: Set<ServiceType> = setOf(ServiceType.TAXI, ServiceType.BIKE, ServiceType.DELIVERY)
)

class DriverViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(DriverUiState())
    val uiState: StateFlow<DriverUiState> = _uiState.asStateFlow()

    private var dispatchJob: Job? = null

    /**
     * Alterna o estado de disponibilidade do motorista para receber chamadas.
     */
    fun toggleOnline() {
        val willBeOnline = !_uiState.value.isOnline
        _uiState.update {
            it.copy(
                isOnline = willBeOnline,
                incomingRequest = if (!willBeOnline) null else it.incomingRequest
            )
        }

        if (willBeOnline) {
            startIncomingRideSimulation()
        } else {
            dispatchJob?.cancel()
            dispatchJob = null
        }
    }

    /**
     * Simula a chegada periódica de chamadas de passageiros quando o motorista está online.
     */
    private fun startIncomingRideSimulation() {
        dispatchJob?.cancel()
        dispatchJob = viewModelScope.launch {
            // Pequeno delay para efeito de busca por chamadas na rede de Luanda
            delay(2500)
            if (_uiState.value.isOnline && _uiState.value.activeAcceptedRide == null) {
                generateRealisticRequest()
            }
        }
    }

    private fun generateRealisticRequest() {
        val sampleRequests = listOf(
            DriverRideRequest(
                id = "REQ-1082",
                passengerName = "Cláudia Silva",
                passengerRating = 4.95,
                serviceType = ServiceType.TAXI,
                pickupAddress = "Belas Shopping, Talatona",
                dropoffAddress = "Largo da Mutamba, Ingombota",
                distanceToPickupKm = 1.1,
                etaPickupMinutes = 4,
                tripDistanceKm = 12.4,
                estimatedEarningsAoa = 3800.0,
                paymentMethod = "Multicaixa Express"
            ),
            DriverRideRequest(
                id = "REQ-1083",
                passengerName = "António Manuel",
                passengerRating = 4.88,
                serviceType = ServiceType.BIKE,
                pickupAddress = "Aeroporto 4 de Fevereiro, Maianga",
                dropoffAddress = "Marginal de Luanda / Baía",
                distanceToPickupKm = 0.8,
                etaPickupMinutes = 3,
                tripDistanceKm = 6.8,
                estimatedEarningsAoa = 1650.0,
                paymentMethod = "Numerário (Kz)"
            ),
            DriverRideRequest(
                id = "REQ-1084",
                passengerName = "Farmácia Luanda Sul",
                passengerRating = 5.0,
                serviceType = ServiceType.DELIVERY,
                pickupAddress = "Viana Estalagem",
                dropoffAddress = "Centralidade do Kilamba",
                distanceToPickupKm = 2.0,
                etaPickupMinutes = 6,
                tripDistanceKm = 14.2,
                estimatedEarningsAoa = 4200.0,
                paymentMethod = "Multicaixa Express"
            )
        )

        // Seleciona uma chamada que corresponda aos serviços habilitados pelo motorista
        val available = sampleRequests.filter { it.serviceType in _uiState.value.acceptedServices }
        val next = available.randomOrNull() ?: sampleRequests.first()

        _uiState.update { it.copy(incomingRequest = next) }
    }

    /**
     * O motorista aceita a corrida recebida.
     */
    fun acceptIncomingRequest() {
        val req = _uiState.value.incomingRequest ?: return
        _uiState.update {
            it.copy(
                activeAcceptedRide = req,
                incomingRequest = null
            )
        }
    }

    /**
     * O motorista recusa a chamada atual e volta a procurar passageiros.
     */
    fun declineIncomingRequest() {
        _uiState.update { it.copy(incomingRequest = null) }
        startIncomingRideSimulation()
    }

    /**
     * Finaliza a corrida aceita, incrementando os ganhos do dia.
     */
    fun completeActiveRide() {
        val active = _uiState.value.activeAcceptedRide ?: return
        _uiState.update {
            it.copy(
                activeAcceptedRide = null,
                todayEarningsAoa = it.todayEarningsAoa + active.estimatedEarningsAoa,
                completedTripsToday = it.completedTripsToday + 1
            )
        }
        startIncomingRideSimulation()
    }

    /**
     * Alterna a preferência por modalidade (Táxi, Bike, Entrega).
     */
    fun toggleServicePreference(serviceType: ServiceType) {
        _uiState.update { current ->
            val updated = current.acceptedServices.toMutableSet()
            if (updated.contains(serviceType)) {
                if (updated.size > 1) { // Manter pelo menos uma ativa
                    updated.remove(serviceType)
                }
            } else {
                updated.add(serviceType)
            }
            current.copy(acceptedServices = updated)
        }
    }
}
