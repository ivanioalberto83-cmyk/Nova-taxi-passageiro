package com.example.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.PassengerActiveRide
import com.example.model.PassengerRideStage
import com.example.model.ServiceType
import com.example.util.NotificationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Estado e alertas em tempo real do acompanhamento da corrida do passageiro.
 */
data class PassengerRideUiState(
    val activeRide: PassengerActiveRide? = null,
    val inAppAlert: String? = null,
    val showArrivalCelebration: Boolean = false
)

/**
 * ViewModel que gere o ciclo de vida da corrida para o passageiro,
 * emitindo notificações locais quando o motorista estiver a chegar ou tiver chegado ao local.
 */
class PassengerRideViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(PassengerRideUiState())
    val uiState: StateFlow<PassengerRideUiState> = _uiState.asStateFlow()

    private var simulationJob: Job? = null

    /**
     * Inicia o acompanhamento de uma nova corrida solicitada pelo passageiro.
     */
    fun startRide(
        context: Context,
        originAddress: String,
        destAddress: String,
        serviceType: ServiceType,
        totalFareAoa: Double,
        driverName: String = "Bernardo Kiala",
        vehicleModel: String = if (serviceType == ServiceType.BIKE) "Yamaha YBR 125 Vermelha" else "Toyota Corolla Branco",
        vehiclePlate: String = if (serviceType == ServiceType.BIKE) "LD-09-31-BK" else "LD-42-88-HA"
    ) {
        simulationJob?.cancel()
        NotificationHelper.createNotificationChannels(context)

        val ride = PassengerActiveRide(
            rideId = "RIDE-${System.currentTimeMillis() % 10000}",
            stage = PassengerRideStage.DRIVER_ASSIGNED,
            serviceType = serviceType,
            originAddress = originAddress,
            destinationAddress = destAddress,
            totalFareAoa = totalFareAoa,
            driverName = driverName,
            driverPhone = "+244 923 456 789",
            vehicleModel = vehicleModel,
            vehiclePlate = vehiclePlate,
            etaMinutes = 4,
            distanceToPickupKm = 1.8,
            arrivingNotificationSent = false,
            arrivedNotificationSent = false
        )

        _uiState.update {
            it.copy(
                activeRide = ride,
                inAppAlert = "Motorista $driverName a caminho (${ride.etaMinutes} min)",
                showArrivalCelebration = false
            )
        }

        // Simulação automática do avanço do motorista para teste realista
        startAutomaticProgression(context)
    }

    /**
     * Progressão automática do motorista até ao ponto de recolha.
     */
    private fun startAutomaticProgression(context: Context) {
        simulationJob = viewModelScope.launch {
            // 1ª etapa: Motorista a aproximar-se (delay de 5 segundos para a simulação)
            delay(5000)
            triggerDriverArriving(context)

            // 2ª etapa: Motorista chega ao ponto de partida (mais 6 segundos)
            delay(6000)
            triggerDriverArrived(context)
        }
    }

    /**
     * Aciona o estado de "Motorista a chegar" e dispara a notificação local.
     */
    fun triggerDriverArriving(context: Context) {
        val current = _uiState.value.activeRide ?: return
        if (current.stage == PassengerRideStage.DRIVER_ARRIVED || current.stage == PassengerRideStage.IN_TRANSIT) {
            return
        }

        val updated = current.copy(
            stage = PassengerRideStage.DRIVER_ARRIVING,
            etaMinutes = 2,
            distanceToPickupKm = 0.35,
            arrivingNotificationSent = true
        )

        _uiState.update {
            it.copy(
                activeRide = updated,
                inAppAlert = "🚕 Atenção: ${updated.driverName} está a chegar ao seu local de partida (${updated.etaMinutes} min)!"
            )
        }

        // Dispara a Notificação Local do Android
        NotificationHelper.showDriverArrivingNotification(
            context = context,
            driverName = updated.driverName,
            vehicleInfo = "${updated.vehicleModel} (${updated.vehiclePlate})",
            etaMinutes = updated.etaMinutes,
            pickupAddress = updated.originAddress,
            rideId = updated.rideId
        )
    }

    /**
     * Aciona o estado de "Motorista chegou ao local de partida" e dispara a notificação local.
     */
    fun triggerDriverArrived(context: Context) {
        val current = _uiState.value.activeRide ?: return
        if (current.stage == PassengerRideStage.IN_TRANSIT || current.stage == PassengerRideStage.COMPLETED) {
            return
        }

        val updated = current.copy(
            stage = PassengerRideStage.DRIVER_ARRIVED,
            etaMinutes = 0,
            distanceToPickupKm = 0.0,
            arrivedNotificationSent = true
        )

        _uiState.update {
            it.copy(
                activeRide = updated,
                inAppAlert = "📍 O motorista ${updated.driverName} chegou ao local de partida (${updated.vehiclePlate})!",
                showArrivalCelebration = true
            )
        }

        // Dispara a Notificação Local do Android
        NotificationHelper.showDriverArrivedNotification(
            context = context,
            driverName = updated.driverName,
            vehicleInfo = "${updated.vehicleModel} (${updated.vehiclePlate})",
            pickupAddress = updated.originAddress,
            rideId = updated.rideId
        )
    }

    /**
     * Passageiro embarcou e inicia a rota até ao destino.
     */
    fun startTripToDestination() {
        val current = _uiState.value.activeRide ?: return
        val updated = current.copy(
            stage = PassengerRideStage.IN_TRANSIT,
            etaMinutes = 12
        )
        _uiState.update {
            it.copy(
                activeRide = updated,
                inAppAlert = "Viagem em andamento para ${updated.destinationAddress}",
                showArrivalCelebration = false
            )
        }
    }

    /**
     * Conclui a corrida e cancela notificações ativas.
     */
    fun completeRide(context: Context) {
        simulationJob?.cancel()
        simulationJob = null
        NotificationHelper.cancelDriverArrivalNotification(context)

        _uiState.update {
            it.copy(
                activeRide = null,
                inAppAlert = "Corrida concluída com sucesso! Obrigado por viajar com a NOVA Táxi.",
                showArrivalCelebration = false
            )
        }
    }

    /**
     * Cancela a corrida ativa.
     */
    fun cancelRide(context: Context) {
        simulationJob?.cancel()
        simulationJob = null
        NotificationHelper.cancelDriverArrivalNotification(context)

        _uiState.update {
            it.copy(
                activeRide = null,
                inAppAlert = "Corrida cancelada.",
                showArrivalCelebration = false
            )
        }
    }

    /**
     * Fecha o alerta visual na interface.
     */
    fun dismissInAppAlert() {
        _uiState.update { it.copy(inAppAlert = null) }
    }
}
