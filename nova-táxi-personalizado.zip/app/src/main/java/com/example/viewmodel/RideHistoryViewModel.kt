package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.model.FareEstimate
import com.example.model.LuandaPlace
import com.example.model.RideHistoryItem
import com.example.model.RideStatus
import com.example.model.ServiceType
import com.example.util.LuandaLocations
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Estado reativo do histórico de corridas realizadas.
 */
data class RideHistoryUiState(
    val rides: List<RideHistoryItem> = emptyList(),
    val selectedFilter: ServiceType? = null, // null significa "Todos"
    val selectedRideDetails: RideHistoryItem? = null,
    val totalRidesCount: Int = 0,
    val totalSpentAoa: Double = 0.0
) {
    val filteredRides: List<RideHistoryItem>
        get() = if (selectedFilter == null) {
            rides
        } else {
            rides.filter { it.serviceType == selectedFilter }
        }

    val formattedTotalSpent: String
        get() = "${totalSpentAoa.toInt()} Kz"
}

/**
 * ViewModel que gere o histórico local de corridas da NOVA Táxi em Luanda.
 */
class RideHistoryViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(RideHistoryUiState())
    val uiState: StateFlow<RideHistoryUiState> = _uiState.asStateFlow()

    private val dateFormatter = SimpleDateFormat("dd MMM, HH:mm", Locale("pt", "AO"))

    init {
        loadInitialHistory()
    }

    /**
     * Inicializa a estrutura de dados local com trajetos realistas em Luanda.
     */
    private fun loadInitialHistory() {
        val places = LuandaLocations.places
        val aeroporto = places.firstOrNull { it.id == "aeroporto" } ?: LuandaLocations.defaultOrigin
        val marginal = places.firstOrNull { it.id == "marginal" } ?: LuandaLocations.defaultDestination
        val talatona = places.firstOrNull { it.id == "talatona" } ?: places[2]
        val kilamba = places.firstOrNull { it.id == "kilamba" } ?: places[4]
        val mutamba = places.firstOrNull { it.id == "mutamba" } ?: places[7]
        val ilha = places.firstOrNull { it.id == "ilha" } ?: places[3]
        val viana = places.firstOrNull { it.id == "viana" } ?: places[5]

        val initialList = listOf(
            RideHistoryItem(
                id = "NV-84920",
                serviceType = ServiceType.TAXI,
                origin = aeroporto,
                destination = marginal,
                distanceKm = 7.1,
                durationMinutes = 22,
                fareAoa = 2850.0,
                dateFormatted = "Hoje, 11:20",
                timestamp = System.currentTimeMillis() - 3600000 * 3,
                status = RideStatus.COMPLETED,
                driverName = "Manuel Domingos",
                driverRating = 4.9,
                vehicleModel = "Toyota Corolla",
                vehiclePlate = "LD-42-88-HA",
                paymentMethod = "Multicaixa Express"
            ),
            RideHistoryItem(
                id = "NV-84812",
                serviceType = ServiceType.BIKE,
                origin = mutamba,
                destination = ilha,
                distanceKm = 4.2,
                durationMinutes = 11,
                fareAoa = 1150.0,
                dateFormatted = "Ontem, 16:45",
                timestamp = System.currentTimeMillis() - 86400000,
                status = RideStatus.COMPLETED,
                driverName = "João Baptista",
                driverRating = 5.0,
                vehicleModel = "Honda CG 125",
                vehiclePlate = "LD-19-45-BK",
                paymentMethod = "Numerário (Kz)"
            ),
            RideHistoryItem(
                id = "NV-84705",
                serviceType = ServiceType.DELIVERY,
                origin = talatona,
                destination = kilamba,
                distanceKm = 11.8,
                durationMinutes = 28,
                fareAoa = 3400.0,
                dateFormatted = "19 Out, 14:10",
                timestamp = System.currentTimeMillis() - 86400000 * 2,
                status = RideStatus.COMPLETED,
                driverName = "António Sebastião",
                driverRating = 4.8,
                vehicleModel = "Suzuki Carry Furgão",
                vehiclePlate = "LD-88-21-CC",
                paymentMethod = "Multicaixa Express"
            ),
            RideHistoryItem(
                id = "NV-84590",
                serviceType = ServiceType.TAXI,
                origin = kilamba,
                destination = talatona,
                distanceKm = 9.4,
                durationMinutes = 26,
                fareAoa = 3600.0,
                dateFormatted = "17 Out, 08:30",
                timestamp = System.currentTimeMillis() - 86400000 * 4,
                status = RideStatus.COMPLETED,
                driverName = "Paulo Afonso",
                driverRating = 4.9,
                vehicleModel = "Hyundai Accent",
                vehiclePlate = "LD-63-12-GG",
                paymentMethod = "Multicaixa Express"
            ),
            RideHistoryItem(
                id = "NV-84411",
                serviceType = ServiceType.BIKE,
                origin = viana,
                destination = aeroporto,
                distanceKm = 14.5,
                durationMinutes = 32,
                fareAoa = 2800.0,
                dateFormatted = "15 Out, 18:05",
                timestamp = System.currentTimeMillis() - 86400000 * 6,
                status = RideStatus.CANCELLED,
                driverName = "Mateus André",
                driverRating = 4.7,
                vehicleModel = "KTM Duke 200",
                vehiclePlate = "LD-02-77-AM",
                paymentMethod = "Numerário (Kz)"
            )
        )

        updateRidesState(initialList)
    }

    /**
     * Adiciona uma nova corrida concluída ao histórico local em tempo real.
     */
    fun recordNewRide(
        serviceType: ServiceType,
        origin: LuandaPlace,
        destination: LuandaPlace,
        estimate: FareEstimate
    ) {
        val now = System.currentTimeMillis()
        val formattedDate = "Hoje, ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now))}"
        val newId = "NV-${(10000..99999).random()}"

        val (driver, vehicle, plate) = when (serviceType) {
            ServiceType.TAXI -> Triple("Bernardo Kiala", "Toyota Yaris", "LD-71-33-JK")
            ServiceType.BIKE -> Triple("Gaspar Neto", "Yamaha YBR 125", "LD-44-19-XP")
            ServiceType.DELIVERY -> Triple("Carlos Dinis", "Piaggio Ape Furgão", "LD-11-92-EF")
        }

        val newRide = RideHistoryItem(
            id = newId,
            serviceType = serviceType,
            origin = origin,
            destination = destination,
            distanceKm = estimate.roadDistanceKm,
            durationMinutes = estimate.estimatedDurationMinutes,
            fareAoa = estimate.totalFareAoa,
            dateFormatted = formattedDate,
            timestamp = now,
            status = RideStatus.COMPLETED,
            driverName = driver,
            driverRating = 5.0,
            vehicleModel = vehicle,
            vehiclePlate = plate,
            paymentMethod = "Multicaixa Express"
        )

        val updated = listOf(newRide) + _uiState.value.rides
        updateRidesState(updated)
    }

    /**
     * Filtra o histórico por modalidade (Táxi, Bike, Entrega ou Todos).
     */
    fun setServiceFilter(serviceType: ServiceType?) {
        _uiState.update { it.copy(selectedFilter = serviceType) }
    }

    /**
     * Define a corrida selecionada para exibição em modal de detalhes.
     */
    fun selectRideForDetails(ride: RideHistoryItem?) {
        _uiState.update { it.copy(selectedRideDetails = ride) }
    }

    private fun updateRidesState(list: List<RideHistoryItem>) {
        val totalSpent = list.filter { it.status == RideStatus.COMPLETED }.sumOf { it.fareAoa }
        _uiState.update {
            it.copy(
                rides = list,
                totalRidesCount = list.size,
                totalSpentAoa = totalSpent
            )
        }
    }
}
